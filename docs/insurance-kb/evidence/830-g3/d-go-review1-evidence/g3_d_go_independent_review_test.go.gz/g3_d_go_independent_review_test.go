package types

import (
  "bytes"
  "compress/gzip"
  "encoding/json"
  "io"
  "os"
  "path/filepath"
  "testing"
)

const independentRoot830G3 = "/Users/houjing/Documents/LLM_wiki/insurancekb-weknora/.worktrees/830-g3-implementation"

func TestIndependentG3OracleFourRejectAndSnapshotsMatchPython(t *testing.T) {
  fixture := filepath.Join(independentRoot830G3, "harness/tests/fixtures/batch_concept_compile_830_g3/candidate.json")
  raw, err := os.ReadFile(fixture)
  if err != nil { t.Fatal(err) }
  bundle, err := ParseBatchConceptCandidateBundle830G3(raw)
  if err != nil { t.Fatalf("positive rejected: %v", err) }
  snapshots, err := bundle.SnapshotMembers()
  if err != nil { t.Fatal(err) }
  expectedRaw, err := os.ReadFile("/private/tmp/g3-d-python-expected-snapshots-01.json")
  if err != nil { t.Fatal(err) }
  var expected []WikiReleaseMemberSnapshot
  if err := json.Unmarshal(expectedRaw, &expected); err != nil { t.Fatal(err) }
  if len(snapshots) != len(expected) { t.Fatalf("snapshot count %d != %d",len(snapshots),len(expected)) }
  for i := range snapshots {
    a,b := snapshots[i], expected[i]
    if a.Kind != b.Kind || a.LogicalSlug != b.LogicalSlug || a.RevisionID != b.RevisionID || a.MemberDigest != b.MemberDigest || a.Title != b.Title || a.Content != b.Content {
      t.Fatalf("snapshot scalar mismatch index=%d id=%s",i,a.LogicalSlug)
    }
    ac, ae := CanonicalConceptMemberPayload830G2(a.Payload)
    bc, be := CanonicalConceptMemberPayload830G2(b.Payload)
    if ae != nil || be != nil || !bytes.Equal(ac,bc) { t.Fatalf("snapshot payload mismatch index=%d id=%s",i,a.LogicalSlug) }
  }
  dir := filepath.Join(independentRoot830G3,"docs/insurance-kb/evidence/830-g3/d-go-c-semantics-oracle-01")
  matches, err := filepath.Glob(filepath.Join(dir,"[0-9][0-9]-*.json.gz"))
  if err != nil || len(matches) != 4 { t.Fatalf("oracle cases: %v count=%d",err,len(matches)) }
  for _, path := range matches {
    file, err := os.Open(path); if err != nil { t.Fatal(err) }
    zr, err := gzip.NewReader(file); if err != nil { file.Close(); t.Fatal(err) }
    attacked, err := io.ReadAll(zr); zr.Close(); file.Close(); if err != nil { t.Fatal(err) }
    if _, err := ParseBatchConceptCandidateBundle830G3(attacked); err == nil {
      t.Fatalf("oracle attack accepted: %s", filepath.Base(path))
    }
  }
}

func TestIndependentG3RejectsOmittedNestedNullable(t *testing.T) {
  fixture := filepath.Join(independentRoot830G3, "harness/tests/fixtures/batch_concept_compile_830_g3/candidate.json")
  raw, err := os.ReadFile(fixture); if err != nil { t.Fatal(err) }
  dec := json.NewDecoder(bytes.NewReader(raw)); dec.UseNumber()
  var tree map[string]any
  if err := dec.Decode(&tree); err != nil { t.Fatal(err) }
  request := tree["request"].(map[string]any)
  confirmation := request["profile_confirmation"].(map[string]any)
  receipt := confirmation["receipt"].(map[string]any)
  if receipt["actor_display_name"] != nil { t.Fatal("fixture nullable is not null") }
  delete(receipt,"actor_display_name")
  attacked, err := json.Marshal(tree); if err != nil { t.Fatal(err) }
  if _, err := ParseBatchConceptCandidateBundle830G3(attacked); err == nil {
    t.Fatalf("BLOCKER: omitted nested actor_display_name accepted as explicit null")
  }
}

func TestIndependentG3RejectsOmittedNestedFieldsMatrix(t *testing.T) {
  fixture := filepath.Join(independentRoot830G3, "harness/tests/fixtures/batch_concept_compile_830_g3/candidate.json")
  raw, err := os.ReadFile(fixture); if err != nil { t.Fatal(err) }
  cases := map[string]func(map[string]any){
    "confirmation actor_display_name": func(tree map[string]any){ delete(tree["request"].(map[string]any)["profile_confirmation"].(map[string]any)["receipt"].(map[string]any), "actor_display_name") },
    "confirmation queue_owner": func(tree map[string]any){ delete(tree["request"].(map[string]any)["profile_confirmation"].(map[string]any)["receipt"].(map[string]any), "queue_owner") },
    "MATCH candidate_id": func(tree map[string]any){
      rows:=tree["request"].(map[string]any)["entity_bindings"].([]any); for _,v:=range rows { m:=v.(map[string]any); if m["resolution_disposition"]=="MATCH" { delete(m,"candidate_id"); return } }; panic("no MATCH")
    },
    "MATCH entity_candidate_sha256": func(tree map[string]any){
      rows:=tree["request"].(map[string]any)["entity_bindings"].([]any); for _,v:=range rows { m:=v.(map[string]any); if m["resolution_disposition"]=="MATCH" { delete(m,"entity_candidate_sha256"); return } }; panic("no MATCH")
    },
    "catalog nullable source_guidance": func(tree map[string]any){
      entries:=tree["request"].(map[string]any)["catalog"].(map[string]any)["entries"].([]any); for _,ev:=range entries { fields:=ev.(map[string]any)["pack"].(map[string]any)["fields"].([]any); for _,fv:=range fields { f:=fv.(map[string]any); if f["source_guidance"]==nil { delete(f,"source_guidance"); return } } }; panic("no null source_guidance")
    },
    "embedded G2 nullable value": func(tree map[string]any){
      fields:=tree["request"].(map[string]any)["base_request"].(map[string]any)["existing_fields"].([]any); for _,fv:=range fields { f:=fv.(map[string]any); if f["value"]==nil { delete(f,"value"); return } }; panic("no null value")
    },
  }
  for name, mutate := range cases {
    t.Run(name, func(t *testing.T){
      dec:=json.NewDecoder(bytes.NewReader(raw)); dec.UseNumber(); var tree map[string]any
      if err:=dec.Decode(&tree); err!=nil { t.Fatal(err) }; mutate(tree)
      attacked,err:=json.Marshal(tree); if err!=nil { t.Fatal(err) }
      if _,err:=ParseBatchConceptCandidateBundle830G3(attacked); err==nil { t.Errorf("BLOCKER accepted omitted nested field: %s",name) }
    })
  }
}

func TestIndependentG3RejectsNullRequiredArray(t *testing.T) {
  raw,err:=os.ReadFile("/private/tmp/g3-d-go-null-approved-aliases-01.json"); if err!=nil { t.Fatal(err) }
  if _,err:=ParseBatchConceptCandidateBundle830G3(raw); err==nil { t.Fatalf("BLOCKER: null accepted for required approved_aliases array") }
}

func TestIndependentG3RejectsInvalidTypedHash(t *testing.T) {
  raw,err:=os.ReadFile("/private/tmp/g3-d-go-invalid-native-capture-hash-01.json"); if err!=nil { t.Fatal(err) }
  if _,err:=ParseBatchConceptCandidateBundle830G3(raw); err==nil { t.Fatalf("BLOCKER: non-hash native_capture_sha256 accepted") }
}

func TestIndependentG3CustomReceiptAndRawMessageOmissionsReject(t *testing.T) {
  raw,err:=os.ReadFile(filepath.Join(independentRoot830G3,"harness/tests/fixtures/batch_concept_compile_830_g3/candidate.json")); if err!=nil { t.Fatal(err) }
  cases:=map[string]func(map[string]any){
    "registered receipt exact keys":func(tree map[string]any){ entries:=tree["request"].(map[string]any)["resolution_inputs"].(map[string]any)["corpus"].(map[string]any)["entries"].([]any); delete(entries[0].(map[string]any)["receipt"].(map[string]any),"binding_digest") },
    "resolution raw nullable presence":func(tree map[string]any){ decisions:=tree["request"].(map[string]any)["resolution"].(map[string]any)["decisions"].([]any); children:=decisions[0].(map[string]any)["children"].([]any); delete(children[0].(map[string]any),"queue_id") },
  }
  for name,mutate:=range cases { t.Run(name,func(t *testing.T){ dec:=json.NewDecoder(bytes.NewReader(raw));dec.UseNumber();var tree map[string]any;if err:=dec.Decode(&tree);err!=nil{t.Fatal(err)};mutate(tree);changed,err:=json.Marshal(tree);if err!=nil{t.Fatal(err)};if _,err:=ParseBatchConceptCandidateBundle830G3(changed);err==nil{t.Fatalf("unexpected acceptance: %s",name)} }) }
}

func TestIndependentG3RejectsNullForNonNullableScalar(t *testing.T) {
  raw,err:=os.ReadFile(filepath.Join(independentRoot830G3,"harness/tests/fixtures/batch_concept_compile_830_g3/candidate.json"));if err!=nil{t.Fatal(err)}
  dec:=json.NewDecoder(bytes.NewReader(raw));dec.UseNumber();var tree map[string]any;if err:=dec.Decode(&tree);err!=nil{t.Fatal(err)}
  fields:=tree["request"].(map[string]any)["base_request"].(map[string]any)["existing_fields"].([]any); changed:=false
  for _,fv:=range fields { f:=fv.(map[string]any); evs:=f["evidence"].([]any); for _,ev:=range evs { e:=ev.(map[string]any); if e["start"]==json.Number("0") { e["start"]=nil;changed=true;break } };if changed{break} }
  if !changed{t.Fatal("no start=0 evidence")}; attacked,err:=json.Marshal(tree);if err!=nil{t.Fatal(err)}
  if _,err:=ParseBatchConceptCandidateBundle830G3(attacked);err==nil{t.Fatalf("BLOCKER: explicit null accepted for nonnullable Evidence.start")}
}
