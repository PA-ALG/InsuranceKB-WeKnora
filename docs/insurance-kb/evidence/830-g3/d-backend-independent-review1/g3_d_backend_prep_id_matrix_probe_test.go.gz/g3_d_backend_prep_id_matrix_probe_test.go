package service

import "testing"

func TestIndependentG3PreparationIDStructuredTextMatrix(t *testing.T) {
    fixture, schema, _ := batchConceptReleaseFixture830G3(t)
    valid := "batch-g3-preparation-valid"
    if _, err := schema.CreateBatchConceptDraft830G3(fixture.ctx, fixture.principal1, fixture.scope, valid, batchConceptCandidateVector830G3(t)); err != nil {
        t.Fatalf("valid control failed: %v", err)
    }
    cases := map[string]string{
        "whitespace-only": "   ",
        "leading-space": " batch-g3-preparation",
        "trailing-space": "batch-g3-preparation ",
        "internal-tab": "batch-g3\tpreparation",
        "internal-del": "batch-g3\x7fpreparation",
        "non-nfc": "batch-g3-e\u0301-preparation",
    }
    for name, id := range cases {
        t.Run(name, func(t *testing.T) {
            if _, err := schema.CreateBatchConceptDraft830G3(fixture.ctx, fixture.principal1, fixture.scope, id, batchConceptCandidateVector830G3(t)); err == nil {
                t.Errorf("accepted invalid G3 structured Text preparation_id %q", id)
            }
        })
    }
}
