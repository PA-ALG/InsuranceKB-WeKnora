package types

import (
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"io"
	"reflect"
	"sort"
	"strings"
	"unicode/utf8"
)

var ErrConceptCandidateBundle830G3 = errors.New("invalid concept candidate bundle 830 g3")

const (
	conceptBatchContract830G3 = "batch-concept-candidate-bundle.830.g3.v1"
	conceptBatchRequest830G3  = "batch-concept-compile-request.830.g3.v1"
	conceptBatchBaseRelease   = "release-9cb493e3-8d27-4a0f-8f29-93e2a078725b"
	conceptBatchBaseMembers   = "260247295fb8530ca298f350d9127f21e412f8155371babc8915c86dc52c7475"
)

type SchemaFieldDefinition830G3 struct {
	FieldKey               string  `json:"field_key"`
	ShortTitle             string  `json:"short_title"`
	SchemaCategory         string  `json:"schema_category"`
	ValueSpec              *string `json:"value_spec"`
	Description            *string `json:"description"`
	SourceGuidance         *string `json:"source_guidance"`
	FormationMethod        *string `json:"formation_method"`
	KnowledgeRole          *string `json:"knowledge_role"`
	CommonFieldMarker      *string `json:"common_field_marker"`
	OtherApplicableProduct *string `json:"other_applicable_products"`
	UsageFrequency         int64   `json:"usage_frequency"`
	SourceRow              int64   `json:"source_row"`
	SemanticSHA256         string  `json:"semantic_sha256"`
}

type SchemaPresentationProfileRef830G3 struct {
	ProfileID      string `json:"profile_id"`
	ProfileVersion string `json:"profile_version"`
}

type SchemaPackDefinition830G3 struct {
	Contract                  string                            `json:"contract"`
	SchemaPackID              string                            `json:"schema_pack_id"`
	SchemaVersion             string                            `json:"schema_version"`
	DisplayName               string                            `json:"display_name"`
	EntityType                string                            `json:"entity_type"`
	ApplicableClassifications []string                          `json:"applicable_classifications"`
	WorkbookSHA256            string                            `json:"workbook_sha256"`
	WorkbookSheet             string                            `json:"workbook_sheet"`
	Fields                    []SchemaFieldDefinition830G3      `json:"fields"`
	PresentationProfileRef    SchemaPresentationProfileRef830G3 `json:"presentation_profile_ref"`
	SchemaPackSHA256          string                            `json:"schema_pack_sha256"`
}

type SchemaPackCatalogEntry830G3 struct {
	Pack                      SchemaPackDefinition830G3          `json:"pack"`
	Profile                   EntityPagePresentationProfile830G1 `json:"profile"`
	ProfileConfirmationStatus string                             `json:"profile_confirmation_status"`
	QualityStatus             string                             `json:"quality_status"`
}

type SchemaPackCatalog830G3 struct {
	Contract                   string                        `json:"contract"`
	CatalogID                  string                        `json:"catalog_id"`
	CatalogVersion             string                        `json:"catalog_version"`
	WorkbookSHA256             string                        `json:"workbook_sha256"`
	MappingConfigSHA256        string                        `json:"mapping_config_sha256"`
	Entries                    []SchemaPackCatalogEntry830G3 `json:"entries"`
	FieldNameUnionCount        int                           `json:"field_name_union_count"`
	FieldNameIntersectionCount int                           `json:"field_name_intersection_count"`
	CatalogSHA256              string                        `json:"catalog_sha256"`
}

type ProfileConfirmationIdentity830G3 struct {
	ProfileID      string `json:"profile_id"`
	ProfileVersion string `json:"profile_version"`
	ProfileSHA256  string `json:"profile_sha256"`
}

type CatalogProfileConfirmationReceipt830G3 struct {
	Contract             string                             `json:"contract"`
	ConfirmedAtRecorded  string                             `json:"confirmed_at_recorded"`
	Decision             string                             `json:"decision"`
	UserReplyVerbatim    string                             `json:"user_reply_verbatim"`
	Actor                string                             `json:"actor"`
	ActorDisplayName     *string                            `json:"actor_display_name"`
	ConfirmationChannel  string                             `json:"confirmation_channel"`
	ReviewDocument       string                             `json:"review_document"`
	ReviewDocumentSHA256 string                             `json:"review_document_sha256"`
	CatalogSHA256        string                             `json:"catalog_sha256"`
	CatalogWireSHA256    string                             `json:"catalog_wire_sha256"`
	Profiles             []ProfileConfirmationIdentity830G3 `json:"profiles"`
	Scope                string                             `json:"scope"`
	NotIncluded          []string                           `json:"not_included"`
	QueueOwner           *string                            `json:"queue_owner"`
	IdentityMetadataNote string                             `json:"identity_metadata_note"`
}

type CatalogProfileConfirmationBinding830G3 struct {
	Contract              string                                 `json:"contract"`
	Receipt               CatalogProfileConfirmationReceipt830G3 `json:"receipt"`
	ReceiptFileSHA256     string                                 `json:"receipt_file_sha256"`
	ReceiptSemanticSHA256 string                                 `json:"receipt_semantic_sha256"`
}

type RegisteredSourceReceipt830G3 struct {
	Contract          string `json:"contract"`
	KnowledgeID       string `json:"knowledge_id"`
	ParseAttempt      int64  `json:"parse_attempt"`
	RevisionSourceID  string `json:"revision_source_id"`
	FileSHA256        string `json:"file_sha256"`
	ObjectSHA256      string `json:"object_sha256"`
	Size              int64  `json:"size"`
	MIMEType          string `json:"mime_type"`
	PageCount         int64  `json:"page_count"`
	ManifestAlgorithm string `json:"manifest_algorithm"`
	ManifestDigest    string `json:"manifest_digest"`
	ChunkCount        int64  `json:"chunk_count"`
	BindingDigest     string `json:"binding_digest"`
	RetentionState    string `json:"retention_state"`
}

type LiveRevisionSourceReceipt830G3 struct {
	Contract                 string `json:"contract"`
	RevisionSourceID         string `json:"revision_source_id"`
	TenantID                 uint64 `json:"tenant_id"`
	SpaceID                  string `json:"space_id"`
	RawKBID                  string `json:"raw_kb_id"`
	WikiKBID                 string `json:"wiki_kb_id"`
	KnowledgeID              string `json:"knowledge_id"`
	EvidenceParseAttemptID   string `json:"evidence_parse_attempt_id"`
	WeKnoraParseAttempt      int64  `json:"weknora_parse_attempt"`
	ResourceID               string `json:"resource_id"`
	FileSHA256               string `json:"file_sha256"`
	Size                     int64  `json:"size"`
	MIMEType                 string `json:"mime_type"`
	PageCount                int64  `json:"page_count"`
	ParsedDocumentSHA256     string `json:"parsed_document_sha256"`
	ParseManifestSHA256      string `json:"parse_manifest_sha256"`
	WeKnoraManifestAlgorithm string `json:"weknora_manifest_algorithm"`
	WeKnoraManifestDigest    string `json:"weknora_manifest_digest"`
	WeKnoraChunkCount        int64  `json:"weknora_chunk_count"`
	SourceReceiptSHA256      string `json:"source_receipt_sha256"`
}

type SourceReceipt830G3 struct {
	Contract   string
	Registered *RegisteredSourceReceipt830G3
	Legacy     *LiveRevisionSourceReceipt830G3
}

func (receipt *SourceReceipt830G3) UnmarshalJSON(raw []byte) error {
	var tag struct {
		Contract string `json:"contract"`
	}
	if !conceptJSONUnicodeValid830G2(raw) || !conceptJSONUniqueKeys830G2(raw) ||
		json.Unmarshal(raw, &tag) != nil || tag.Contract == "" {
		return ErrConceptCandidateBundle830G3
	}
	switch tag.Contract {
	case "knowledge-revision-source.v1":
		var value RegisteredSourceReceipt830G3
		if decodeExactObject830G3(raw, &value, registeredReceiptKeys830G3, true) != nil {
			return ErrConceptCandidateBundle830G3
		}
		receipt.Contract, receipt.Registered = tag.Contract, &value
	case "live-revision-source-receipt.v1":
		var value LiveRevisionSourceReceipt830G3
		if decodeExactObject830G3(raw, &value, legacyReceiptKeys830G3, true) != nil {
			return ErrConceptCandidateBundle830G3
		}
		receipt.Contract, receipt.Legacy = tag.Contract, &value
	default:
		return ErrConceptCandidateBundle830G3
	}
	return nil
}

func (receipt SourceReceipt830G3) MarshalJSON() ([]byte, error) {
	if receipt.Registered != nil && receipt.Legacy == nil {
		return json.Marshal(receipt.Registered)
	}
	if receipt.Legacy != nil && receipt.Registered == nil {
		return json.Marshal(receipt.Legacy)
	}
	return nil, ErrConceptCandidateBundle830G3
}

var registeredReceiptKeys830G3 = []string{
	"binding_digest", "chunk_count", "contract", "file_sha256", "knowledge_id",
	"manifest_algorithm", "manifest_digest", "mime_type", "object_sha256", "page_count",
	"parse_attempt", "retention_state", "revision_source_id", "size",
}

var legacyReceiptKeys830G3 = []string{
	"contract", "evidence_parse_attempt_id", "file_sha256", "knowledge_id", "mime_type",
	"page_count", "parse_manifest_sha256", "parsed_document_sha256", "raw_kb_id",
	"resource_id", "revision_source_id", "size", "source_receipt_sha256", "space_id",
	"tenant_id", "weknora_chunk_count", "weknora_manifest_algorithm",
	"weknora_manifest_digest", "weknora_parse_attempt", "wiki_kb_id",
}

type SourceProvenance830G3 struct {
	ProvenanceID             string `json:"provenance_id"`
	Kind                     string `json:"kind"`
	SourceURI                string `json:"source_uri"`
	AcquisitionReceiptSHA256 string `json:"acquisition_receipt_sha256"`
	DeclaredBy               string `json:"declared_by"`
	DeclarationSHA256        string `json:"declaration_sha256"`
}

type CorpusEntry830G3 struct {
	MaterialID           string                    `json:"material_id"`
	Receipt              SourceReceipt830G3        `json:"receipt"`
	NativeCaptureSHA256  string                    `json:"native_capture_sha256"`
	ParserIdentitySHA256 string                    `json:"parser_identity_sha256"`
	Blocks               []ConceptSourceBlock830G2 `json:"blocks"`
	Provenance           SourceProvenance830G3     `json:"provenance"`
	EntrySHA256          string                    `json:"entry_sha256"`
}

type BatchCorpus830G3 struct {
	Contract     string             `json:"contract"`
	TenantID     uint64             `json:"tenant_id"`
	SpaceID      string             `json:"space_id"`
	RawKBID      string             `json:"raw_kb_id"`
	WikiKBID     string             `json:"wiki_kb_id"`
	Entries      []CorpusEntry830G3 `json:"entries"`
	CorpusSHA256 string             `json:"corpus_sha256"`
}

type BatchResolutionInputs830G3 struct {
	Contract         string           `json:"contract"`
	Corpus           BatchCorpus830G3 `json:"corpus"`
	Proposals        json.RawMessage  `json:"proposals"`
	ExistingEntities json.RawMessage  `json:"existing_entities"`
	Policy           json.RawMessage  `json:"policy"`
	InputsSHA256     string           `json:"inputs_sha256"`
}

type ResolutionDecisionRef830G3 struct {
	MaterialID                     string `json:"material_id"`
	ProposalRef                    string `json:"proposal_ref"`
	DecisionSHA256                 string `json:"decision_sha256"`
	ClassificationAssignmentSHA256 string `json:"classification_assignment_sha256"`
}

type BoundResolutionEvidence830G3 struct {
	MaterialID  string               `json:"material_id"`
	ProposalRef string               `json:"proposal_ref"`
	EvidenceID  string               `json:"evidence_id"`
	Purpose     string               `json:"purpose"`
	Evidence    ConceptEvidence830G2 `json:"evidence"`
}

type CandidateVersionAnchor830G3 struct {
	Kind            string `json:"kind"`
	ObservedValue   string `json:"observed_value"`
	NormalizedValue string `json:"normalized_value"`
}

type EntityCompileBinding830G3 struct {
	Contract                  string                         `json:"contract"`
	EntityID                  string                         `json:"entity_id"`
	EntityVersion             string                         `json:"entity_version"`
	ResolutionDisposition     string                         `json:"resolution_disposition"`
	ResolutionRefs            []ResolutionDecisionRef830G3   `json:"resolution_refs"`
	EntityKeySHA256           string                         `json:"entity_key_sha256"`
	VersionCandidateKeySHA256 string                         `json:"version_candidate_key_sha256"`
	CandidateID               *string                        `json:"candidate_id"`
	EntityCandidateSHA256     *string                        `json:"entity_candidate_sha256"`
	DisplayName               string                         `json:"display_name"`
	Issuer                    string                         `json:"issuer"`
	ProductCode               string                         `json:"product_code"`
	VersionLabel              string                         `json:"version_label"`
	VersionAnchor             CandidateVersionAnchor830G3    `json:"version_anchor"`
	PrimaryClassification     string                         `json:"primary_classification"`
	SchemaPackID              string                         `json:"schema_pack_id"`
	SchemaVersion             string                         `json:"schema_version"`
	SchemaPackSHA256          string                         `json:"schema_pack_sha256"`
	ProfileID                 string                         `json:"profile_id"`
	ProfileVersion            string                         `json:"profile_version"`
	ProfileSHA256             string                         `json:"profile_sha256"`
	RequiredFields            []string                       `json:"required_fields"`
	SourceMaterialIDs         []string                       `json:"source_material_ids"`
	ResolutionEvidence        []BoundResolutionEvidence830G3 `json:"resolution_evidence"`
	BindingSHA256             string                         `json:"binding_sha256"`
}

type UnknownFieldKeyAlignment830G3 struct {
	Contract              string `json:"contract"`
	SourceReleaseID       string `json:"source_release_id"`
	SourceActivationEpoch uint64 `json:"source_activation_epoch"`
	SourceCandidateSHA256 string `json:"source_candidate_sha256"`
	EntityID              string `json:"entity_id"`
	EntityVersion         string `json:"entity_version"`
	OldFieldKey           string `json:"old_field_key"`
	NewFieldKey           string `json:"new_field_key"`
	OldMemberID           string `json:"old_member_id"`
	OldMemberDigest       string `json:"old_member_digest"`
	NewMemberID           string `json:"new_member_id"`
	NewMemberDigest       string `json:"new_member_digest"`
	AlignmentSHA256       string `json:"alignment_sha256"`
}

type BatchConceptCompileRequest830G3 struct {
	Contract                  string                                 `json:"contract"`
	BaseRequest               ConceptCompileRequest830G2             `json:"base_request"`
	Catalog                   SchemaPackCatalog830G3                 `json:"catalog"`
	CatalogWireSHA256         string                                 `json:"catalog_wire_sha256"`
	ProfileConfirmation       CatalogProfileConfirmationBinding830G3 `json:"profile_confirmation"`
	ResolutionInputs          BatchResolutionInputs830G3             `json:"resolution_inputs"`
	Resolution                json.RawMessage                        `json:"resolution"`
	EntityBindings            []EntityCompileBinding830G3            `json:"entity_bindings"`
	UnknownFieldKeyAlignments []UnknownFieldKeyAlignment830G3        `json:"unknown_field_key_alignments"`
	QualityStatus             string                                 `json:"quality_status"`
	ReleaseLane               string                                 `json:"release_lane"`
	RequestSHA256             string                                 `json:"request_sha256"`
}

type BatchConceptPageManifest830G3 struct {
	Contract      string                         `json:"contract"`
	Members       []ConceptPageMember830G2       `json:"members"`
	MembersSHA256 string                         `json:"members_sha256"`
	Audit         []ConceptAuditDisposition830G2 `json:"audit"`
}

type BatchConceptCandidateBundle830G3 struct {
	Contract           string                          `json:"contract"`
	Request            BatchConceptCompileRequest830G3 `json:"request"`
	ModelCompileResult ConceptCompileResult830G2       `json:"model_compile_result"`
	CompileResult      ConceptCompileResult830G2       `json:"compile_result"`
	ReviewResult       ConceptReviewResult830G2        `json:"review_result"`
	PageManifest       BatchConceptPageManifest830G3   `json:"page_manifest"`
	Admission          ConceptAdmission830G2           `json:"admission"`
	CandidateHash      string                          `json:"candidate_hash"`
}

type batchResolutionSummary830G3 struct {
	Contract                     string            `json:"contract"`
	CompilerVersion              string            `json:"compiler_version"`
	SpaceID                      string            `json:"space_id"`
	CatalogSHA256                string            `json:"catalog_sha256"`
	CorpusSHA256                 string            `json:"corpus_sha256"`
	ProposalsSHA256              string            `json:"proposals_sha256"`
	ExistingSnapshotSHA256       string            `json:"existing_snapshot_sha256"`
	PolicySHA256                 string            `json:"policy_sha256"`
	ModelExecutionReceiptSHA256s []string          `json:"model_execution_receipt_sha256s"`
	Decisions                    []json.RawMessage `json:"decisions"`
	MaterialCount                int               `json:"material_count"`
	ResolutionDecisionCount      int               `json:"resolution_decision_count"`
	ModelAttemptedCount          int               `json:"model_attempted_count"`
	DispositionCounts            json.RawMessage   `json:"disposition_counts"`
	BatchSHA256                  string            `json:"batch_sha256"`
}

var batchBundleKeys830G3 = []string{
	"admission", "candidate_hash", "compile_result", "contract", "model_compile_result",
	"page_manifest", "request", "review_result",
}

var batchRequestKeys830G3 = []string{
	"base_request", "catalog", "catalog_wire_sha256", "contract", "entity_bindings",
	"profile_confirmation", "quality_status", "release_lane", "request_sha256", "resolution",
	"resolution_inputs", "unknown_field_key_alignments",
}

var entityBindingKeys830G3 = []string{
	"binding_sha256", "candidate_id", "contract", "display_name", "entity_candidate_sha256",
	"entity_id", "entity_key_sha256", "entity_version", "issuer", "primary_classification",
	"product_code", "profile_id", "profile_sha256", "profile_version", "required_fields",
	"resolution_disposition", "resolution_evidence", "resolution_refs", "schema_pack_id",
	"schema_pack_sha256", "schema_version", "source_material_ids", "version_anchor",
	"version_candidate_key_sha256", "version_label",
}

var alignmentKeys830G3 = []string{
	"alignment_sha256", "contract", "entity_id", "entity_version", "new_field_key",
	"new_member_digest", "new_member_id", "old_field_key", "old_member_digest",
	"old_member_id", "source_activation_epoch", "source_candidate_sha256",
	"source_release_id",
}

func ParseBatchConceptCandidateBundle830G3(raw []byte) (BatchConceptCandidateBundle830G3, error) {
	var bundle BatchConceptCandidateBundle830G3
	if decodeExactObject830G3(raw, &bundle, batchBundleKeys830G3, true) != nil {
		return bundle, ErrConceptCandidateBundle830G3
	}
	if validateBatchConceptBundle830G3(bundle) != nil {
		return BatchConceptCandidateBundle830G3{}, ErrConceptCandidateBundle830G3
	}
	return bundle, nil
}

func CanonicalBatchConceptCandidateBundle830G3(raw []byte) (
	BatchConceptCandidateBundle830G3, []byte, error,
) {
	bundle, err := ParseBatchConceptCandidateBundle830G3(raw)
	if err != nil {
		return BatchConceptCandidateBundle830G3{}, nil, ErrConceptCandidateBundle830G3
	}
	canonical, err := canonicalConceptRawJSON830G2(raw)
	if err != nil {
		return BatchConceptCandidateBundle830G3{}, nil, ErrConceptCandidateBundle830G3
	}
	return bundle, canonical, nil
}

func (bundle BatchConceptCandidateBundle830G3) SnapshotMembers() (
	[]WikiReleaseMemberSnapshot, error,
) {
	if validateBatchConceptBundle830G3(bundle) != nil {
		return nil, ErrConceptCandidateBundle830G3
	}
	result := make([]WikiReleaseMemberSnapshot, 0, len(bundle.PageManifest.Members))
	for _, member := range bundle.PageManifest.Members {
		digest, err := batchConceptHash830G3("batch-concept-member.830.g3.v1", member)
		if err != nil {
			return nil, ErrConceptCandidateBundle830G3
		}
		result = append(result, WikiReleaseMemberSnapshot{
			Kind: member.Kind, LogicalSlug: member.MemberID, RevisionID: bundle.CandidateHash,
			MemberDigest: digest, Title: member.Title, Content: member.Content,
			Payload: append(json.RawMessage(nil), member.Payload...),
		})
	}
	return result, nil
}

func decodeExactObject830G3(raw []byte, destination any, keys []string, exact bool) error {
	if !utf8.Valid(raw) || !conceptJSONUnicodeValid830G2(raw) || !conceptJSONUniqueKeys830G2(raw) {
		return ErrConceptCandidateBundle830G3
	}
	var fields map[string]json.RawMessage
	if err := json.Unmarshal(raw, &fields); err != nil {
		return ErrConceptCandidateBundle830G3
	}
	if exact {
		if len(fields) != len(keys) {
			return ErrConceptCandidateBundle830G3
		}
		for _, key := range keys {
			if _, ok := fields[key]; !ok {
				return ErrConceptCandidateBundle830G3
			}
		}
	} else {
		for _, key := range keys {
			if _, ok := fields[key]; !ok {
				return ErrConceptCandidateBundle830G3
			}
		}
	}
	decoder := json.NewDecoder(bytes.NewReader(raw))
	decoder.DisallowUnknownFields()
	if err := decoder.Decode(destination); err != nil {
		return ErrConceptCandidateBundle830G3
	}
	var trailing any
	if err := decoder.Decode(&trailing); !errors.Is(err, io.EOF) {
		return ErrConceptCandidateBundle830G3
	}
	return nil
}

func batchConceptHash830G3(objectType string, payload any) (string, error) {
	if objectType == "" || !isASCIIControlFree830G3(objectType) {
		return "", ErrConceptCandidateBundle830G3
	}
	canonical, err := conceptCanonicalJSON830G2(payload)
	if err != nil {
		return "", ErrConceptCandidateBundle830G3
	}
	preimage := append([]byte(schemaWikiHashPrefix), []byte(objectType)...)
	preimage = append(preimage, 0)
	preimage = append(preimage, canonical...)
	sum := sha256.Sum256(preimage)
	return hex.EncodeToString(sum[:]), nil
}

func batchConceptHashWithout830G3(objectType string, value any, hashKey string) (string, error) {
	raw, err := json.Marshal(value)
	if err != nil {
		return "", err
	}
	decoder := json.NewDecoder(bytes.NewReader(raw))
	decoder.UseNumber()
	var payload map[string]any
	if err := decoder.Decode(&payload); err != nil {
		return "", err
	}
	delete(payload, hashKey)
	return batchConceptHash830G3(objectType, payload)
}

func isASCIIControlFree830G3(value string) bool {
	if value == "" || !utf8.ValidString(value) {
		return false
	}
	for _, character := range value {
		if character > 0x7f || character < 0x20 || character == 0x7f {
			return false
		}
	}
	return true
}

func validHash830G3(value string) bool {
	if len(value) != 64 {
		return false
	}
	_, err := hex.DecodeString(value)
	return err == nil && strings.ToLower(value) == value
}

func hashEqualWithout830G3(objectType string, value any, key, actual string) bool {
	expected, err := batchConceptHashWithout830G3(objectType, value, key)
	return err == nil && expected == actual
}

func canonicalRawEqualValue830G3(raw string, value any) bool {
	if !conceptJSONUnicodeValid830G2([]byte(raw)) || !conceptJSONUniqueKeys830G2([]byte(raw)) {
		return false
	}
	left, errLeft := canonicalConceptRawJSON830G2([]byte(raw))
	right, errRight := conceptCanonicalJSON830G2(value)
	return errLeft == nil && errRight == nil && bytes.Equal(left, right)
}

func validateRawContractHash830G3(
	raw json.RawMessage, contract, hashKey string, keys []string,
) (string, error) {
	var payload map[string]any
	if decodeExactObject830G3(raw, &payload, keys, true) != nil || payload["contract"] != contract {
		return "", ErrConceptCandidateBundle830G3
	}
	actual, ok := payload[hashKey].(string)
	if !ok || !validHash830G3(actual) {
		return "", ErrConceptCandidateBundle830G3
	}
	delete(payload, hashKey)
	expected, err := batchConceptHash830G3(contract, payload)
	if err != nil || expected != actual {
		return "", ErrConceptCandidateBundle830G3
	}
	return actual, nil
}

func validateSchemaCatalog830G3(catalog SchemaPackCatalog830G3, wireHash string) error {
	if catalog.Contract != "schema-pack-catalog.830.g3.v1" || len(catalog.Entries) != 11 ||
		catalog.FieldNameUnionCount != 154 || catalog.FieldNameIntersectionCount != 47 ||
		!validHash830G3(catalog.CatalogSHA256) {
		return ErrConceptCandidateBundle830G3
	}
	canonical, err := conceptCanonicalJSON830G2(catalog)
	if err != nil {
		return ErrConceptCandidateBundle830G3
	}
	wireSum := sha256.Sum256(canonical)
	if hex.EncodeToString(wireSum[:]) != wireHash ||
		!hashEqualWithout830G3(catalog.Contract, catalog, "catalog_sha256", catalog.CatalogSHA256) {
		return ErrConceptCandidateBundle830G3
	}
	packIDs := map[string]bool{}
	profileIDs := map[string]bool{}
	union := map[string]bool{}
	var intersection map[string]bool
	for _, entry := range catalog.Entries {
		pack, profile := entry.Pack, entry.Profile
		packKey := pack.SchemaPackID + "\x00" + pack.SchemaVersion
		profileKey := profile.ProfileID + "\x00" + profile.ProfileVersion
		if packIDs[packKey] || profileIDs[profileKey] || pack.Contract != "schema-pack-definition.830.g3.v1" ||
			pack.EntityType != "insurance_product" || len(pack.ApplicableClassifications) != 1 ||
			pack.WorkbookSHA256 != catalog.WorkbookSHA256 || len(pack.Fields) == 0 ||
			entry.ProfileConfirmationStatus != "PENDING_PRODUCT_OWNER_CONFIRMATION" ||
			entry.QualityStatus != "REGISTERED_NOT_QUALITY_ADMITTED" ||
			validateEntityPageProfile830G1(profile) != nil ||
			profile.SchemaPackID != pack.SchemaPackID || profile.SchemaVersion != pack.SchemaVersion ||
			profile.SchemaPackSHA256 != pack.SchemaPackSHA256 ||
			profile.ProfileID != pack.PresentationProfileRef.ProfileID ||
			profile.ProfileVersion != pack.PresentationProfileRef.ProfileVersion ||
			!hashEqualWithout830G3(pack.Contract, pack, "schema_pack_sha256", pack.SchemaPackSHA256) {
			return ErrConceptCandidateBundle830G3
		}
		packIDs[packKey], profileIDs[profileKey] = true, true
		fieldKeys := map[string]bool{}
		for _, field := range pack.Fields {
			if fieldKeys[field.FieldKey] || field.FieldKey == "" || field.SourceRow <= 5 ||
				field.UsageFrequency < 0 || !validHash830G3(field.SemanticSHA256) {
				return ErrConceptCandidateBundle830G3
			}
			fieldKeys[field.FieldKey], union[field.FieldKey] = true, true
			metadata := map[string]any{
				"field_key": field.FieldKey, "short_title": field.ShortTitle,
				"schema_category": field.SchemaCategory, "value_spec": field.ValueSpec,
				"description": field.Description, "source_guidance": field.SourceGuidance,
				"formation_method": field.FormationMethod, "knowledge_role": field.KnowledgeRole,
				"common_field_marker":       field.CommonFieldMarker,
				"other_applicable_products": field.OtherApplicableProduct,
				"usage_frequency":           field.UsageFrequency,
			}
			expected, hashErr := batchConceptHash830G3(
				"schema-field-definition.830.g3.v1",
				map[string]any{"schema_pack_id": pack.SchemaPackID, "field": metadata},
			)
			if hashErr != nil || expected != field.SemanticSHA256 {
				return ErrConceptCandidateBundle830G3
			}
		}
		if intersection == nil {
			intersection = fieldKeys
		} else {
			for key := range intersection {
				if !fieldKeys[key] {
					delete(intersection, key)
				}
			}
		}
		ordered := make([]string, 0, len(pack.Fields))
		for _, section := range profile.Sections {
			for _, field := range section.Fields {
				ordered = append(ordered, field.FieldKey)
			}
		}
		if len(ordered) != len(fieldKeys) {
			return ErrConceptCandidateBundle830G3
		}
		for _, key := range ordered {
			if !fieldKeys[key] {
				return ErrConceptCandidateBundle830G3
			}
			delete(fieldKeys, key)
		}
		if len(fieldKeys) != 0 {
			return ErrConceptCandidateBundle830G3
		}
	}
	if len(union) != catalog.FieldNameUnionCount || len(intersection) != catalog.FieldNameIntersectionCount {
		return ErrConceptCandidateBundle830G3
	}
	return nil
}

var proposalKeys830G3 = []string{
	"contract", "corpus_sha256", "model_receipts", "proposals", "proposals_sha256",
}
var existingKeys830G3 = []string{
	"base_activation_epoch", "base_release_id", "contract", "entities", "head_receipt_sha256",
	"raw_kb_id", "resolver_policy_sha256", "resolver_version", "snapshot_sha256", "space_id",
	"tenant_id", "wiki_kb_id",
}
var policyKeys830G3 = []string{
	"auto_candidate_requires", "classification_threshold", "contract", "identity_threshold",
	"policy_id", "policy_sha256", "policy_version", "queue_id", "queue_owner", "rules",
	"taxonomy_id", "taxonomy_version",
}
var resolutionKeys830G3 = []string{
	"batch_sha256", "catalog_sha256", "compiler_version", "corpus_sha256", "decisions",
	"disposition_counts", "existing_snapshot_sha256", "material_count", "model_attempted_count",
	"model_execution_receipt_sha256s", "policy_sha256", "proposals_sha256",
	"resolution_decision_count", "space_id", "contract",
}

func validateResolutionInputs830G3(inputs BatchResolutionInputs830G3) (
	proposalHash, existingHash, policyHash string, err error,
) {
	if inputs.Contract != "batch-resolution-inputs.830.g3.v1" ||
		validateBatchCorpus830G3(inputs.Corpus) != nil ||
		!hashEqualWithout830G3(inputs.Contract, inputs, "inputs_sha256", inputs.InputsSHA256) {
		return "", "", "", ErrConceptCandidateBundle830G3
	}
	proposalHash, err = validateRawContractHash830G3(
		inputs.Proposals, "batch-identity-proposals.830.g3.v1", "proposals_sha256", proposalKeys830G3,
	)
	if err != nil {
		return "", "", "", err
	}
	existingHash, err = validateRawContractHash830G3(
		inputs.ExistingEntities, "existing-entities.830.g3.v1", "snapshot_sha256", existingKeys830G3,
	)
	if err != nil {
		return "", "", "", err
	}
	policyHash, err = validateRawContractHash830G3(
		inputs.Policy, "batch-resolution-policy.830.g3.v1", "policy_sha256", policyKeys830G3,
	)
	return proposalHash, existingHash, policyHash, err
}

func validateBatchCorpus830G3(corpus BatchCorpus830G3) error {
	if corpus.Contract != "batch-corpus.830.g3.v1" || corpus.TenantID == 0 ||
		!conceptIdentity830G2(corpus.SpaceID) || !conceptIdentity830G2(corpus.RawKBID) ||
		!conceptIdentity830G2(corpus.WikiKBID) || len(corpus.Entries) == 0 ||
		!hashEqualWithout830G3(corpus.Contract, corpus, "corpus_sha256", corpus.CorpusSHA256) {
		return ErrConceptCandidateBundle830G3
	}
	previous := ""
	for _, entry := range corpus.Entries {
		if entry.MaterialID <= previous || validateCorpusEntry830G3(corpus, entry) != nil {
			return ErrConceptCandidateBundle830G3
		}
		previous = entry.MaterialID
	}
	return nil
}

func validateCorpusEntry830G3(corpus BatchCorpus830G3, entry CorpusEntry830G3) error {
	if !conceptIdentity830G2(entry.MaterialID) || len(entry.Blocks) == 0 ||
		!hashEqualWithout830G3("source-provenance.830.g3.v1", entry.Provenance,
			"declaration_sha256", entry.Provenance.DeclarationSHA256) ||
		!hashEqualWithout830G3("corpus-entry.830.g3.v1", entry, "entry_sha256", entry.EntrySHA256) {
		return ErrConceptCandidateBundle830G3
	}
	var knowledge, revision, file, manifest string
	var attempt, pages int64
	if entry.Receipt.Registered != nil && entry.Receipt.Legacy == nil {
		receipt := entry.Receipt.Registered
		if receipt.Contract != "knowledge-revision-source.v1" || receipt.ParseAttempt <= 0 ||
			receipt.Size <= 0 || receipt.PageCount <= 0 || receipt.ChunkCount <= 0 ||
			receipt.ManifestAlgorithm != "weknora.chunk_manifest.v1" ||
			receipt.FileSHA256 != receipt.ObjectSHA256 || receipt.RetentionState != "pinned" {
			return ErrConceptCandidateBundle830G3
		}
		knowledge, revision, file, manifest = receipt.KnowledgeID, receipt.RevisionSourceID,
			receipt.FileSHA256, receipt.ManifestDigest
		attempt, pages = receipt.ParseAttempt, receipt.PageCount
	} else if entry.Receipt.Legacy != nil && entry.Receipt.Registered == nil {
		receipt := entry.Receipt.Legacy
		if receipt.Contract != "live-revision-source-receipt.v1" || receipt.TenantID != corpus.TenantID ||
			receipt.SpaceID != corpus.SpaceID || receipt.RawKBID != corpus.RawKBID ||
			receipt.WikiKBID != corpus.WikiKBID || receipt.WeKnoraParseAttempt <= 0 ||
			receipt.Size <= 0 || receipt.PageCount <= 0 || receipt.WeKnoraChunkCount <= 0 {
			return ErrConceptCandidateBundle830G3
		}
		knowledge, revision, file, manifest = receipt.KnowledgeID, receipt.RevisionSourceID,
			receipt.FileSHA256, receipt.WeKnoraManifestDigest
		attempt, pages = receipt.WeKnoraParseAttempt, receipt.PageCount
	} else {
		return ErrConceptCandidateBundle830G3
	}
	previous := ""
	for _, block := range entry.Blocks {
		key := block.RevisionID + "\x00" + block.BlockID
		if key <= previous || validateConceptSource830G2(block) != nil ||
			block.TenantID != corpus.TenantID || block.SpaceID != corpus.SpaceID ||
			block.RawKBID != corpus.RawKBID || block.KnowledgeID != knowledge ||
			block.ParseAttempt != attempt || block.RevisionID != revision ||
			block.SourceHash != file || block.ParseHash != manifest ||
			block.ParserIdentity != entry.ParserIdentitySHA256 || int64(block.PageNumber) > pages {
			return ErrConceptCandidateBundle830G3
		}
		previous = key
	}
	return nil
}

func validateProfileConfirmation830G3(
	confirmation CatalogProfileConfirmationBinding830G3, catalog SchemaPackCatalog830G3,
) error {
	if confirmation.Contract != "catalog-profile-confirmation-binding.830.g3.v1" ||
		confirmation.Receipt.Contract != "830-g3-profile-user-confirmation.v1" ||
		confirmation.Receipt.Decision != "CONFIRMED" ||
		confirmation.Receipt.CatalogSHA256 != catalog.CatalogSHA256 ||
		confirmation.Receipt.CatalogWireSHA256 == "" ||
		confirmation.ReceiptFileSHA256 != "7f6141c63db4a77e3d13a0a8d632ea5463761bedeee7bd1aabef165d68c86863" {
		return ErrConceptCandidateBundle830G3
	}
	expected, err := batchConceptHash830G3(confirmation.Receipt.Contract, confirmation.Receipt)
	if err != nil || expected != confirmation.ReceiptSemanticSHA256 ||
		len(confirmation.Receipt.Profiles) != len(catalog.Entries) {
		return ErrConceptCandidateBundle830G3
	}
	profiles := map[string]string{}
	for _, entry := range catalog.Entries {
		profiles[entry.Profile.ProfileID+"\x00"+entry.Profile.ProfileVersion] = entry.Profile.ProfileSHA256
	}
	seen := map[string]bool{}
	for _, profile := range confirmation.Receipt.Profiles {
		key := profile.ProfileID + "\x00" + profile.ProfileVersion
		if seen[key] || profiles[key] != profile.ProfileSHA256 {
			return ErrConceptCandidateBundle830G3
		}
		seen[key] = true
	}
	return nil
}

func validateBatchRequest830G3(request BatchConceptCompileRequest830G3) error {
	if request.Contract != conceptBatchRequest830G3 ||
		request.QualityStatus != "REGISTERED_NOT_QUALITY_ADMITTED" ||
		request.ReleaseLane != "ISOLATED_NOT_FOR_PRODUCTION" ||
		!hashEqualWithout830G3(request.Contract, request, "request_sha256", request.RequestSHA256) ||
		validateConceptRequest830G2(request.BaseRequest) != nil ||
		validateSchemaCatalog830G3(request.Catalog, request.CatalogWireSHA256) != nil ||
		validateProfileConfirmation830G3(request.ProfileConfirmation, request.Catalog) != nil ||
		request.ProfileConfirmation.Receipt.CatalogWireSHA256 != request.CatalogWireSHA256 {
		return ErrConceptCandidateBundle830G3
	}
	base := request.BaseRequest
	basePayload := map[string]any{
		"base_release_id": base.BaseReleaseID, "base_activation_epoch": base.BaseActivationEpoch,
		"existing_definitions": base.ExistingDefinitions, "existing_fields": base.ExistingFields,
		"existing_pages": base.ExistingPages, "existing_entity_versions": base.ExistingEntityVersions,
	}
	baseHash, err := batchConceptHash830G3("actual-base-members.830.g3.v1", basePayload)
	if err != nil || base.BaseReleaseID != conceptBatchBaseRelease || base.BaseActivationEpoch != 5 ||
		len(base.ExistingFields) != 134 || baseHash != conceptBatchBaseMembers {
		return ErrConceptCandidateBundle830G3
	}
	proposalHash, existingHash, policyHash, err := validateResolutionInputs830G3(request.ResolutionInputs)
	if err != nil {
		return ErrConceptCandidateBundle830G3
	}
	var resolution batchResolutionSummary830G3
	if decodeExactObject830G3(request.Resolution, &resolution, resolutionKeys830G3, true) != nil ||
		resolution.Contract != "batch-entity-resolution.830.g3.v1" ||
		!hashEqualWithout830G3(resolution.Contract, resolution, "batch_sha256", resolution.BatchSHA256) ||
		resolution.SpaceID != base.SpaceID || resolution.CatalogSHA256 != request.Catalog.CatalogSHA256 ||
		resolution.CorpusSHA256 != request.ResolutionInputs.Corpus.CorpusSHA256 ||
		resolution.ProposalsSHA256 != proposalHash || resolution.ExistingSnapshotSHA256 != existingHash ||
		resolution.PolicySHA256 != policyHash {
		return ErrConceptCandidateBundle830G3
	}
	if request.ResolutionInputs.Corpus.TenantID != base.TenantID ||
		request.ResolutionInputs.Corpus.SpaceID != base.SpaceID ||
		request.ResolutionInputs.Corpus.RawKBID != base.RawKBID ||
		request.ResolutionInputs.Corpus.WikiKBID != base.WikiKBID {
		return ErrConceptCandidateBundle830G3
	}
	if len(request.EntityBindings) != len(base.RequiredFields) ||
		len(request.UnknownFieldKeyAlignments) != 2 {
		return ErrConceptCandidateBundle830G3
	}
	bindings := map[string]EntityCompileBinding830G3{}
	previous := ""
	for _, binding := range request.EntityBindings {
		if binding.EntityID <= previous || bindings[binding.EntityID].EntityID != "" ||
			validateEntityBinding830G3(binding, request.Catalog, base) != nil {
			return ErrConceptCandidateBundle830G3
		}
		bindings[binding.EntityID], previous = binding, binding.EntityID
	}
	for entityID, version := range base.ExistingEntityVersions {
		binding, ok := bindings[entityID]
		if !ok || binding.ResolutionDisposition != "MATCH" || binding.EntityVersion != version ||
			binding.PrimaryClassification != "medical_insurance" ||
			binding.SchemaPackID != "schemapack_medical_insurance" ||
			binding.SchemaVersion != "2026-08-12-v5" ||
			binding.SchemaPackSHA256 != "5a7938dcb86327f12dbff6e3056271e03c63842ba34904eefebb5bcdc8694079" ||
			binding.ProfileID != "profile_medical_insurance" ||
			binding.ProfileVersion != "1.0.0-candidate" ||
			binding.ProfileSHA256 != "61595e9b2fec127dfca4c31ef95f161d55a9b0939211316b4508ccc4b7d21cf3" {
			return ErrConceptCandidateBundle830G3
		}
	}
	profileRows := make([]map[string]string, 0, len(request.EntityBindings))
	for _, binding := range request.EntityBindings {
		profileRows = append(profileRows, map[string]string{
			"entity_id": binding.EntityID, "profile_id": binding.ProfileID,
			"profile_version": binding.ProfileVersion, "profile_sha256": binding.ProfileSHA256,
		})
	}
	profileHash, err := batchConceptHash830G3("batch-profile-bindings.830.g3.v1", profileRows)
	if err != nil || base.SchemaIdentity != "catalog:"+request.Catalog.CatalogID+"@"+
		request.Catalog.CatalogVersion+"#"+request.Catalog.CatalogSHA256 ||
		base.ProfileIdentity != "profile-set:"+profileHash ||
		base.PolicyIdentity != "g3-resolution-policy:"+resolution.PolicySHA256 {
		return ErrConceptCandidateBundle830G3
	}
	if validateUnknownAlignments830G3(request, bindings) != nil {
		return ErrConceptCandidateBundle830G3
	}
	return nil
}

func validateEntityBinding830G3(
	binding EntityCompileBinding830G3, catalog SchemaPackCatalog830G3,
	base ConceptCompileRequest830G2,
) error {
	if binding.Contract != "entity-compile-binding.830.g3.v1" ||
		!hashEqualWithout830G3(binding.Contract, binding, "binding_sha256", binding.BindingSHA256) ||
		binding.EntityVersion != base.EntityVersions[binding.EntityID] ||
		!reflect.DeepEqual(binding.RequiredFields, base.RequiredFields[binding.EntityID]) ||
		len(binding.ResolutionRefs) == 0 || !sortedUniqueStrings830G3(binding.SourceMaterialIDs) ||
		(binding.ResolutionDisposition == "MATCH" &&
			(binding.CandidateID != nil || binding.EntityCandidateSHA256 != nil)) ||
		(binding.ResolutionDisposition == "CREATE" &&
			(binding.CandidateID == nil || binding.EntityCandidateSHA256 == nil)) ||
		(binding.ResolutionDisposition != "MATCH" && binding.ResolutionDisposition != "CREATE") {
		return ErrConceptCandidateBundle830G3
	}
	var entry *SchemaPackCatalogEntry830G3
	for index := range catalog.Entries {
		candidate := &catalog.Entries[index]
		if candidate.Pack.SchemaPackID == binding.SchemaPackID &&
			candidate.Pack.SchemaVersion == binding.SchemaVersion &&
			candidate.Pack.SchemaPackSHA256 == binding.SchemaPackSHA256 {
			if entry != nil {
				return ErrConceptCandidateBundle830G3
			}
			entry = candidate
		}
	}
	if entry == nil || entry.Pack.ApplicableClassifications[0] != binding.PrimaryClassification ||
		entry.Profile.ProfileID != binding.ProfileID ||
		entry.Profile.ProfileVersion != binding.ProfileVersion ||
		entry.Profile.ProfileSHA256 != binding.ProfileSHA256 {
		return ErrConceptCandidateBundle830G3
	}
	ordered := make([]string, 0, len(entry.Pack.Fields))
	for _, section := range entry.Profile.Sections {
		for _, field := range section.Fields {
			ordered = append(ordered, field.FieldKey)
		}
	}
	if !reflect.DeepEqual(ordered, binding.RequiredFields) {
		return ErrConceptCandidateBundle830G3
	}
	for index, ref := range binding.ResolutionRefs {
		if !conceptIdentity830G2(ref.MaterialID) || !conceptIdentity830G2(ref.ProposalRef) ||
			!validHash830G3(ref.DecisionSHA256) || !validHash830G3(ref.ClassificationAssignmentSHA256) ||
			(index > 0 && (binding.ResolutionRefs[index-1].MaterialID > ref.MaterialID ||
				(binding.ResolutionRefs[index-1].MaterialID == ref.MaterialID &&
					binding.ResolutionRefs[index-1].ProposalRef >= ref.ProposalRef))) {
			return ErrConceptCandidateBundle830G3
		}
	}
	for index, evidence := range binding.ResolutionEvidence {
		if validateConceptEvidenceShape830G2(evidence.Evidence) != nil ||
			(index > 0 && (binding.ResolutionEvidence[index-1].MaterialID > evidence.MaterialID ||
				(binding.ResolutionEvidence[index-1].MaterialID == evidence.MaterialID &&
					binding.ResolutionEvidence[index-1].EvidenceID >= evidence.EvidenceID))) {
			return ErrConceptCandidateBundle830G3
		}
	}
	return nil
}

func sortedUniqueStrings830G3(values []string) bool {
	for index, value := range values {
		if !conceptIdentity830G2(value) || index > 0 && values[index-1] >= value {
			return false
		}
	}
	return true
}

func validateUnknownAlignments830G3(
	request BatchConceptCompileRequest830G3, bindings map[string]EntityCompileBinding830G3,
) error {
	expectedHashes := []string{
		"de1a8ca7a18882403fb97312531fd770e4bf5fa822b08db3c61b93bb828b22ce",
		"fbba36cd2226893f51e6ac2333523a22d5854938a987676e1075186df834d069",
	}
	oldByKey := map[string]ConceptFieldAssertion830G2{}
	for _, field := range request.BaseRequest.ExistingFields {
		oldByKey[field.EntityID+"\x00"+field.FieldKey] = field
	}
	medical := bindings["ping-an-e-sheng-bao"]
	entry := catalogEntryForBinding830G3(request.Catalog, medical)
	if entry == nil {
		return ErrConceptCandidateBundle830G3
	}
	title := ""
	for _, section := range entry.Profile.Sections {
		for _, field := range section.Fields {
			if field.FieldKey == "social_insurance_requirements" {
				title = field.ShortTitle
			}
		}
	}
	for index, row := range request.UnknownFieldKeyAlignments {
		if row.Contract != "unknown-field-key-alignment.830.g3.v1" ||
			row.AlignmentSHA256 != expectedHashes[index] ||
			!hashEqualWithout830G3(row.Contract, row, "alignment_sha256", row.AlignmentSHA256) ||
			row.SourceReleaseID != conceptBatchBaseRelease || row.SourceActivationEpoch != 5 ||
			row.SourceCandidateSHA256 != "bdc806e2084afde6651e85c83a88e3d5395487398bea9b4b2c509473a663d684" ||
			row.OldFieldKey != "social_insurance_requirement" ||
			row.NewFieldKey != "social_insurance_requirements" ||
			(index > 0 && request.UnknownFieldKeyAlignments[index-1].EntityID >= row.EntityID) {
			return ErrConceptCandidateBundle830G3
		}
		old, ok := oldByKey[row.EntityID+"\x00"+row.OldFieldKey]
		if !ok || old.State != "unknown" || !old.Attempted || old.Value != nil ||
			old.UnknownReason == nil || len(old.Evidence) != 0 || len(old.Conditions) != 0 ||
			len(old.Exceptions) != 0 || len(old.ConceptIDs) != 0 || old.ValidTime != "" ||
			old.EntityVersion != row.EntityVersion {
			return ErrConceptCandidateBundle830G3
		}
		oldID, err := conceptFieldID830G2(old)
		if err != nil || oldID != row.OldMemberID {
			return ErrConceptCandidateBundle830G3
		}
		oldPayload, _ := json.Marshal(old)
		oldMember := ConceptPageMember830G2{
			Kind: "field_assertion", MemberID: oldID, OwnerID: old.EntityID,
			Title: old.FieldKey, Content: conceptFieldContent830G3(old), Payload: oldPayload,
		}
		oldDigest, err := conceptDigest830G2("concept-member", oldMember)
		if err != nil || oldDigest != row.OldMemberDigest {
			return ErrConceptCandidateBundle830G3
		}
		updated := old
		updated.FieldKey = row.NewFieldKey
		newID, err := conceptFieldID830G2(updated)
		if err != nil || newID != row.NewMemberID {
			return ErrConceptCandidateBundle830G3
		}
		newPayload, _ := json.Marshal(updated)
		newMember := ConceptPageMember830G2{
			Kind: "field_assertion", MemberID: newID, OwnerID: updated.EntityID,
			Title: title, Content: conceptFieldContent830G3(updated), Payload: newPayload,
		}
		newDigest, err := batchConceptHash830G3("batch-concept-member.830.g3.v1", newMember)
		if err != nil || newDigest != row.NewMemberDigest {
			return ErrConceptCandidateBundle830G3
		}
	}
	return nil
}

func catalogEntryForBinding830G3(
	catalog SchemaPackCatalog830G3, binding EntityCompileBinding830G3,
) *SchemaPackCatalogEntry830G3 {
	for index := range catalog.Entries {
		entry := &catalog.Entries[index]
		if entry.Pack.SchemaPackID == binding.SchemaPackID &&
			entry.Pack.SchemaVersion == binding.SchemaVersion &&
			entry.Pack.SchemaPackSHA256 == binding.SchemaPackSHA256 {
			return entry
		}
	}
	return nil
}

func alignedFields830G3(request BatchConceptCompileRequest830G3) (
	[]ConceptFieldAssertion830G2, error,
) {
	rows := map[string]UnknownFieldKeyAlignment830G3{}
	for _, row := range request.UnknownFieldKeyAlignments {
		rows[row.EntityID+"\x00"+row.OldFieldKey] = row
	}
	result := make([]ConceptFieldAssertion830G2, 0, len(request.BaseRequest.ExistingFields))
	for _, field := range request.BaseRequest.ExistingFields {
		if row, ok := rows[field.EntityID+"\x00"+field.FieldKey]; ok {
			field.FieldKey = row.NewFieldKey
		}
		result = append(result, field)
	}
	sort.Slice(result, func(i, j int) bool {
		if result[i].EntityID == result[j].EntityID {
			return result[i].FieldKey < result[j].FieldKey
		}
		return result[i].EntityID < result[j].EntityID
	})
	return result, nil
}

func conceptFieldContent830G3(field ConceptFieldAssertion830G2) string {
	lines := make([]string, 0, 1+len(field.Conditions)+len(field.Exceptions)+1)
	switch field.State {
	case "present":
		lines = append(lines, "值："+valueOrEmpty830G3(field.Value))
	case "absent_explicitly":
		lines = append(lines, "明确不提供："+valueOrEmpty830G3(field.Value))
	default:
		lines = append(lines, "未知："+valueOrEmpty830G3(field.UnknownReason))
	}
	for _, condition := range field.Conditions {
		lines = append(lines, "条件："+condition)
	}
	for _, exception := range field.Exceptions {
		lines = append(lines, "例外："+exception)
	}
	if field.ValidTime != "" {
		lines = append(lines, "有效期："+field.ValidTime)
	}
	return strings.Join(lines, "\n")
}

func valueOrEmpty830G3(value *string) string {
	if value == nil {
		return ""
	}
	return *value
}

func validateExecution830G3(record ConceptExecutionRecord830G2, output any, contextHash string) error {
	rawSum := sha256.Sum256([]byte(record.RawOutput))
	if !conceptIdentity830G2(record.RunID) || !conceptIdentity830G2(record.Implementation) ||
		record.ContextHash != contextHash || hex.EncodeToString(rawSum[:]) != record.RawOutputHash ||
		!canonicalRawEqualValue830G3(record.RawOutput, output) {
		return ErrConceptCandidateBundle830G3
	}
	return nil
}

func compileRequestHash830G3(request ConceptCompileRequest830G2) (string, error) {
	return conceptDigest830G2("compile-request", request)
}

func compileOutputHash830G3(output ConceptCompileOutput830G2) (string, error) {
	return conceptDigest830G2("compile-output", output)
}

func validateBatchConceptBundle830G3(bundle BatchConceptCandidateBundle830G3) error {
	if bundle.Contract != conceptBatchContract830G3 || validateBatchRequest830G3(bundle.Request) != nil ||
		bundle.Admission.Contract != "concept-admission.830.g2.v1" ||
		bundle.Admission.Status != "NEEDS_HUMAN" ||
		validateDelta830G3(bundle.Request, bundle.ModelCompileResult.Output) != nil {
		return ErrConceptCandidateBundle830G3
	}
	baseRequestHash, err := compileRequestHash830G3(bundle.Request.BaseRequest)
	if err != nil {
		return ErrConceptCandidateBundle830G3
	}
	compilerContext := map[string]any{
		"request": bundle.Request, "request_sha256": bundle.Request.RequestSHA256,
		"base_request_hash": baseRequestHash, "output_mode": "NEW_MEMBERS_ONLY",
	}
	compilerContextHash, err := batchConceptHash830G3(
		"batch-concept-compile-context.830.g3.v1", compilerContext,
	)
	if err != nil || validateExecution830G3(
		bundle.ModelCompileResult.Execution, bundle.ModelCompileResult.Output, compilerContextHash,
	) != nil {
		return ErrConceptCandidateBundle830G3
	}
	expected, err := composeBatchOutput830G3(bundle.Request, bundle.ModelCompileResult.Output)
	if err != nil || !conceptCanonicalEqual830G2(expected, bundle.CompileResult.Output) ||
		bundle.CompileResult.Execution.Implementation != "base-carry-compiler.830.g3.v1" {
		return ErrConceptCandidateBundle830G3
	}
	modelExecutionHash, err := batchConceptHash830G3(
		"batch-concept-model-execution.830.g3.v1", bundle.ModelCompileResult.Execution,
	)
	if err != nil {
		return ErrConceptCandidateBundle830G3
	}
	modelOutputHash, err := compileOutputHash830G3(bundle.ModelCompileResult.Output)
	if err != nil {
		return ErrConceptCandidateBundle830G3
	}
	carryContextHash, err := batchConceptHash830G3(
		"batch-concept-carry-context.830.g3.v1", map[string]any{
			"request_sha256":                 bundle.Request.RequestSHA256,
			"model_compile_output_hash":      modelOutputHash,
			"model_compile_execution_sha256": modelExecutionHash,
		},
	)
	if err != nil || validateExecution830G3(
		bundle.CompileResult.Execution, bundle.CompileResult.Output, carryContextHash,
	) != nil {
		return ErrConceptCandidateBundle830G3
	}
	finalHash, err := compileOutputHash830G3(expected)
	if err != nil || bundle.ReviewResult.Output.RequestHash != baseRequestHash ||
		bundle.ReviewResult.Output.OutputHash != finalHash || bundle.ReviewResult.Output.Decision == "REJECT" {
		return ErrConceptCandidateBundle830G3
	}
	reviewContextHash, err := batchConceptHash830G3(
		"batch-concept-review-context.830.g3.v1", map[string]any{
			"request": bundle.Request, "candidate": expected,
			"request_sha256":    bundle.Request.RequestSHA256,
			"base_request_hash": baseRequestHash, "output_hash": finalHash,
		},
	)
	if err != nil || validateExecution830G3(
		bundle.ReviewResult.Execution, bundle.ReviewResult.Output, reviewContextHash,
	) != nil {
		return ErrConceptCandidateBundle830G3
	}
	runs := map[string]bool{
		bundle.ModelCompileResult.Execution.RunID: true,
		bundle.CompileResult.Execution.RunID:      true,
		bundle.ReviewResult.Execution.RunID:       true,
	}
	if len(runs) != 3 || validatePageManifest830G3(bundle.Request, expected, bundle.PageManifest) != nil ||
		!hashEqualWithout830G3(bundle.Contract, bundle, "candidate_hash", bundle.CandidateHash) {
		return ErrConceptCandidateBundle830G3
	}
	return nil
}

func validateDelta830G3(
	request BatchConceptCompileRequest830G3, output ConceptCompileOutput830G2,
) error {
	requestHash, err := compileRequestHash830G3(request.BaseRequest)
	if err != nil || output.Contract != "concept-compile-output.830.g2.v1" ||
		output.RequestHash != requestHash || len(output.Fields) != 208 {
		return ErrConceptCandidateBundle830G3
	}
	aligned, err := alignedFields830G3(request)
	if err != nil {
		return ErrConceptCandidateBundle830G3
	}
	carried := map[string]bool{}
	for _, field := range aligned {
		carried[field.EntityID+"\x00"+field.FieldKey] = true
	}
	expected := map[string]bool{}
	for entityID, keys := range request.BaseRequest.RequiredFields {
		for _, key := range keys {
			pair := entityID + "\x00" + key
			if !carried[pair] {
				expected[pair] = true
			}
		}
	}
	objects := map[string]bool{}
	for _, field := range output.Fields {
		pair := field.EntityID + "\x00" + field.FieldKey
		id, idErr := conceptFieldID830G2(field)
		if idErr != nil || !expected[pair] || objects[id] ||
			field.EntityVersion != request.BaseRequest.EntityVersions[field.EntityID] ||
			validateConceptField830G2(field) != nil {
			return ErrConceptCandidateBundle830G3
		}
		objects[id] = true
	}
	if len(objects) != len(expected) {
		return ErrConceptCandidateBundle830G3
	}
	oldDefinitions, oldPages := map[string]bool{}, map[string]bool{}
	for _, definition := range request.BaseRequest.ExistingDefinitions {
		id, _ := conceptDefinitionID830G2(definition)
		oldDefinitions[id] = true
	}
	for _, page := range request.BaseRequest.ExistingPages {
		id, _ := conceptFreePageID830G2(page)
		oldPages[id] = true
	}
	for _, definition := range output.Definitions {
		id, idErr := conceptDefinitionID830G2(definition)
		if idErr != nil || oldDefinitions[id] || objects[id] {
			return ErrConceptCandidateBundle830G3
		}
		objects[id] = true
	}
	for _, page := range output.Pages {
		id, idErr := conceptFreePageID830G2(page)
		if idErr != nil || oldPages[id] || objects[id] {
			return ErrConceptCandidateBundle830G3
		}
		objects[id] = true
	}
	audit := map[string]ConceptAuditDisposition830G2{}
	for _, item := range output.Audit {
		if audit[item.Key].Key != "" || (item.Disposition != "new_page" &&
			item.Disposition != "sense" && item.Disposition != "field_rule") {
			return ErrConceptCandidateBundle830G3
		}
		audit[item.Key] = item
	}
	if len(audit) != len(objects) {
		return ErrConceptCandidateBundle830G3
	}
	for key := range objects {
		if audit[key].Key == "" {
			return ErrConceptCandidateBundle830G3
		}
	}
	return nil
}

func composeBatchOutput830G3(
	request BatchConceptCompileRequest830G3, delta ConceptCompileOutput830G2,
) (ConceptCompileOutput830G2, error) {
	aligned, err := alignedFields830G3(request)
	if err != nil {
		return ConceptCompileOutput830G2{}, ErrConceptCandidateBundle830G3
	}
	definitions := append(append([]ConceptDefinition830G2{}, request.BaseRequest.ExistingDefinitions...), delta.Definitions...)
	fields := append(append([]ConceptFieldAssertion830G2{}, aligned...), delta.Fields...)
	pages := append(append([]ConceptFreeWikiPage830G2{}, request.BaseRequest.ExistingPages...), delta.Pages...)
	sort.Slice(definitions, func(i, j int) bool {
		left, _ := conceptDefinitionID830G2(definitions[i])
		right, _ := conceptDefinitionID830G2(definitions[j])
		return left < right
	})
	sort.Slice(fields, func(i, j int) bool {
		if fields[i].EntityID == fields[j].EntityID {
			return fields[i].FieldKey < fields[j].FieldKey
		}
		return fields[i].EntityID < fields[j].EntityID
	})
	sort.Slice(pages, func(i, j int) bool {
		left, _ := conceptFreePageID830G2(pages[i])
		right, _ := conceptFreePageID830G2(pages[j])
		return left < right
	})
	alignedIDs := map[string]bool{}
	for _, row := range request.UnknownFieldKeyAlignments {
		alignedIDs[row.NewMemberID] = true
	}
	audit := make([]ConceptAuditDisposition830G2, 0,
		len(request.BaseRequest.ExistingDefinitions)+len(aligned)+len(request.BaseRequest.ExistingPages)+len(delta.Audit))
	for _, definition := range request.BaseRequest.ExistingDefinitions {
		id, _ := conceptDefinitionID830G2(definition)
		audit = append(audit, ConceptAuditDisposition830G2{Key: id, Disposition: "alias_link", Reason: "BASE_CARRYOVER"})
	}
	for _, field := range aligned {
		id, _ := conceptFieldID830G2(field)
		reason := "BASE_CARRYOVER"
		if alignedIDs[id] {
			reason = "BASE_UNKNOWN_KEY_ALIGNMENT"
		}
		audit = append(audit, ConceptAuditDisposition830G2{Key: id, Disposition: "field_rule", Reason: reason})
	}
	for _, page := range request.BaseRequest.ExistingPages {
		id, _ := conceptFreePageID830G2(page)
		audit = append(audit, ConceptAuditDisposition830G2{Key: id, Disposition: "alias_link", Reason: "BASE_CARRYOVER"})
	}
	audit = append(audit, delta.Audit...)
	sort.Slice(audit, func(i, j int) bool { return audit[i].Key < audit[j].Key })
	result := ConceptCompileOutput830G2{
		Contract: "concept-compile-output.830.g2.v1", RequestHash: delta.RequestHash,
		Definitions: definitions, Fields: fields, Pages: pages, Audit: audit,
		Transformation: delta.Transformation,
	}
	if len(fields) != 342 || validateConceptOutput830G2(request.BaseRequest, result) != nil {
		return ConceptCompileOutput830G2{}, ErrConceptCandidateBundle830G3
	}
	return result, nil
}

type DirectoryField830G3 struct {
	FieldKey   string `json:"field_key"`
	ShortTitle string `json:"short_title"`
	MemberID   string `json:"member_id"`
}

type DirectorySection830G3 struct {
	SectionKey  string                `json:"section_key"`
	DisplayName string                `json:"display_name"`
	Fields      []DirectoryField830G3 `json:"fields"`
}

type EntityDirectoryEntry830G3 struct {
	Contract              string                  `json:"contract"`
	EntityID              string                  `json:"entity_id"`
	EntityVersion         string                  `json:"entity_version"`
	DisplayName           string                  `json:"display_name"`
	Issuer                string                  `json:"issuer"`
	ProductCode           string                  `json:"product_code"`
	PrimaryClassification string                  `json:"primary_classification"`
	SchemaPackID          string                  `json:"schema_pack_id"`
	SchemaVersion         string                  `json:"schema_version"`
	SchemaPackSHA256      string                  `json:"schema_pack_sha256"`
	SchemaPackDisplayName string                  `json:"schema_pack_display_name"`
	ProfileID             string                  `json:"profile_id"`
	ProfileVersion        string                  `json:"profile_version"`
	ProfileSHA256         string                  `json:"profile_sha256"`
	QualityStatus         string                  `json:"quality_status"`
	ReleaseLane           string                  `json:"release_lane"`
	Sections              []DirectorySection830G3 `json:"sections"`
}

func validatePageManifest830G3(
	request BatchConceptCompileRequest830G3, output ConceptCompileOutput830G2,
	manifest BatchConceptPageManifest830G3,
) error {
	if manifest.Contract != "batch-concept-page-manifest.830.g3.v1" ||
		!reflect.DeepEqual(manifest.Audit, output.Audit) || len(manifest.Members) != 354 ||
		!hashEqualWithout830G3("batch-concept-page-members.830.g3.v1",
			struct {
				Members []ConceptPageMember830G2 `json:"members"`
			}{manifest.Members}, "unused", manifest.MembersSHA256) {
		// The members hash payload has no removable field, so verify it directly below.
		membersHash, err := batchConceptHash830G3(
			"batch-concept-page-members.830.g3.v1",
			map[string]any{"members": manifest.Members},
		)
		if err != nil || membersHash != manifest.MembersSHA256 ||
			manifest.Contract != "batch-concept-page-manifest.830.g3.v1" ||
			!reflect.DeepEqual(manifest.Audit, output.Audit) || len(manifest.Members) != 354 {
			return ErrConceptCandidateBundle830G3
		}
	}
	expected, err := projectBatchMembers830G3(request, output)
	if err != nil || !conceptCanonicalEqual830G2(expected, manifest) {
		return ErrConceptCandidateBundle830G3
	}
	return nil
}

func projectBatchMembers830G3(
	request BatchConceptCompileRequest830G3, output ConceptCompileOutput830G2,
) (BatchConceptPageManifest830G3, error) {
	bindings := map[string]EntityCompileBinding830G3{}
	titles := map[string]string{}
	for _, binding := range request.EntityBindings {
		bindings[binding.EntityID] = binding
		entry := catalogEntryForBinding830G3(request.Catalog, binding)
		if entry == nil {
			return BatchConceptPageManifest830G3{}, ErrConceptCandidateBundle830G3
		}
		for _, section := range entry.Profile.Sections {
			for _, field := range section.Fields {
				titles[binding.EntityID+"\x00"+field.FieldKey] = field.ShortTitle
			}
		}
	}
	fieldIndex := map[string]ConceptFieldAssertion830G2{}
	members := make([]ConceptPageMember830G2, 0, len(output.Fields)+len(output.Pages)+len(output.Definitions)+2*len(bindings))
	for _, definition := range output.Definitions {
		id, err := conceptDefinitionID830G2(definition)
		if err != nil {
			return BatchConceptPageManifest830G3{}, ErrConceptCandidateBundle830G3
		}
		payload, _ := json.Marshal(definition)
		members = append(members, ConceptPageMember830G2{
			Kind: "concept", MemberID: id, OwnerID: request.BaseRequest.SpaceID,
			Title: definition.Title, Content: definition.Body, Payload: payload,
		})
	}
	for _, field := range output.Fields {
		id, err := conceptFieldID830G2(field)
		if err != nil {
			return BatchConceptPageManifest830G3{}, ErrConceptCandidateBundle830G3
		}
		fieldIndex[field.EntityID+"\x00"+field.FieldKey] = field
		payload, _ := json.Marshal(field)
		members = append(members, ConceptPageMember830G2{
			Kind: "field_assertion", MemberID: id, OwnerID: field.EntityID,
			Title:   titles[field.EntityID+"\x00"+field.FieldKey],
			Content: conceptFieldContent830G3(field), Payload: payload,
		})
	}
	for _, page := range output.Pages {
		id, err := conceptFreePageID830G2(page)
		if err != nil {
			return BatchConceptPageManifest830G3{}, ErrConceptCandidateBundle830G3
		}
		payload, _ := json.Marshal(page)
		members = append(members, ConceptPageMember830G2{
			Kind: "free_wiki_item", MemberID: id, OwnerID: page.EntityID,
			Title: page.Title, Content: conceptFreePageContent830G3(page), Payload: payload,
		})
	}
	entityIDs := make([]string, 0, len(bindings))
	for entityID := range bindings {
		entityIDs = append(entityIDs, entityID)
	}
	sort.Strings(entityIDs)
	for _, entityID := range entityIDs {
		binding := bindings[entityID]
		entry := catalogEntryForBinding830G3(request.Catalog, binding)
		if entry == nil {
			return BatchConceptPageManifest830G3{}, ErrConceptCandidateBundle830G3
		}
		sections := make([]DirectorySection830G3, 0, len(entry.Profile.Sections))
		sectionNames := make([]string, 0, len(entry.Profile.Sections))
		for _, section := range entry.Profile.Sections {
			fields := make([]DirectoryField830G3, 0, len(section.Fields))
			for _, profileField := range section.Fields {
				field, ok := fieldIndex[entityID+"\x00"+profileField.FieldKey]
				if !ok {
					return BatchConceptPageManifest830G3{}, ErrConceptCandidateBundle830G3
				}
				id, _ := conceptFieldID830G2(field)
				fields = append(fields, DirectoryField830G3{
					FieldKey: profileField.FieldKey, ShortTitle: profileField.ShortTitle, MemberID: id,
				})
			}
			sections = append(sections, DirectorySection830G3{
				SectionKey: section.SectionKey, DisplayName: section.DisplayName, Fields: fields,
			})
			sectionNames = append(sectionNames, section.DisplayName)
		}
		directory := EntityDirectoryEntry830G3{
			Contract: "entity-directory-entry.830.g3.v1", EntityID: entityID,
			EntityVersion: binding.EntityVersion, DisplayName: binding.DisplayName,
			Issuer: binding.Issuer, ProductCode: binding.ProductCode,
			PrimaryClassification: binding.PrimaryClassification,
			SchemaPackID:          binding.SchemaPackID, SchemaVersion: binding.SchemaVersion,
			SchemaPackSHA256:      binding.SchemaPackSHA256,
			SchemaPackDisplayName: entry.Pack.DisplayName,
			ProfileID:             binding.ProfileID, ProfileVersion: binding.ProfileVersion,
			ProfileSHA256: binding.ProfileSHA256, QualityStatus: request.QualityStatus,
			ReleaseLane: request.ReleaseLane, Sections: sections,
		}
		directoryPayload, _ := json.Marshal(directory)
		overviewID, _ := conceptDigest830G2(
			"entity-group", []string{request.BaseRequest.SpaceID, entityID, "entity_overview"},
		)
		members = append(members, ConceptPageMember830G2{
			Kind: "entity_overview", MemberID: "entity_overview_" + overviewID,
			OwnerID: entityID, Title: binding.DisplayName,
			Content: "产品：" + binding.DisplayName + "\n分类：" + binding.PrimaryClassification +
				"\nSchemaPack：" + entry.Pack.DisplayName + "\n栏目：" + strings.Join(sectionNames, "、"),
			Payload: directoryPayload,
		})
		freeIDs := make([]string, 0)
		for _, member := range members {
			if member.OwnerID == entityID && member.Kind == "free_wiki_item" {
				freeIDs = append(freeIDs, member.MemberID)
			}
		}
		sort.Strings(freeIDs)
		freePayload, _ := json.Marshal(map[string]any{"member_ids": freeIDs})
		freeID, _ := conceptDigest830G2(
			"entity-group", []string{request.BaseRequest.SpaceID, entityID, "free_wiki"},
		)
		members = append(members, ConceptPageMember830G2{
			Kind: "free_wiki", MemberID: "free_wiki_" + freeID, OwnerID: entityID,
			Title: "开放知识", Content: "", Payload: freePayload,
		})
	}
	sort.Slice(members, func(i, j int) bool {
		if members[i].Kind == members[j].Kind {
			return members[i].MemberID < members[j].MemberID
		}
		return members[i].Kind < members[j].Kind
	})
	membersHash, err := batchConceptHash830G3(
		"batch-concept-page-members.830.g3.v1", map[string]any{"members": members},
	)
	if err != nil {
		return BatchConceptPageManifest830G3{}, ErrConceptCandidateBundle830G3
	}
	return BatchConceptPageManifest830G3{
		Contract: "batch-concept-page-manifest.830.g3.v1", Members: members,
		MembersSHA256: membersHash, Audit: output.Audit,
	}, nil
}

func conceptFreePageContent830G3(page ConceptFreeWikiPage830G2) string {
	lines := []string{page.Body}
	for _, condition := range page.Conditions {
		lines = append(lines, "条件："+condition)
	}
	for _, exception := range page.Exceptions {
		lines = append(lines, "例外："+exception)
	}
	if page.ValidTime != "" {
		lines = append(lines, "有效期："+page.ValidTime)
	}
	return strings.Join(lines, "\n")
}
