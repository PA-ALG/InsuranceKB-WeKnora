from __future__ import annotations

import importlib
import importlib.util
import json
from pathlib import Path
from types import ModuleType
from typing import Any

import pytest

ROOT = Path(__file__).parents[2]
BASE_BUNDLE = ROOT / "docs/insurance-kb/evidence/830-g2/b-source-complete-candidate-bundle.json"
CATALOG = ROOT / "docs/insurance-kb/evidence/830-g3/catalog/catalog.json"
ALIGNMENTS = (
    ROOT
    / "docs/insurance-kb/evidence/830-g3/unknown-field-key-alignment-exact-fixture.json"
)
G3_FIXTURE = ROOT / "harness/tests/fixtures/batch_concept_compile_830_g3/candidate.json"
G3_PREPARATION = (
    ROOT / "harness/tests/fixtures/batch_concept_compile_830_g3/preparation-request.json"
)
G3_PROVENANCE = ROOT / "harness/tests/fixtures/batch_concept_compile_830_g3/provenance.json"


def _g2() -> ModuleType:
    return importlib.import_module(
        "insurance_harness.knowledge_compiler.concept_compile_830_g2"
    )


def _current_alignment_validator() -> Any:
    """Use the current seam until the G3 module exists; never fail on a missing import."""

    name = "insurance_harness.knowledge_compiler.batch_concept_compile_830_g3"
    if importlib.util.find_spec(name) is None:
        return lambda request, output, _rows: _g2().validate_output(request, output)
    return importlib.import_module(name).validate_unknown_field_key_alignments


def _aligned_output(*, tamper_unknown_reason: bool) -> tuple[Any, Any, tuple[dict[str, Any], ...]]:
    g2 = _g2()
    catalog_api = importlib.import_module(
        "insurance_harness.knowledge_compiler.schema_pack_catalog_830_g3"
    )
    bundle = g2.CandidateBundle.model_validate_json(BASE_BUNDLE.read_text())
    catalog = catalog_api.validate_catalog(CATALOG.read_bytes())
    medical = next(
        entry
        for entry in catalog.entries
        if entry.pack.schema_pack_id == "schemapack_medical_insurance"
    )
    required = tuple(
        field.field_key for section in medical.profile.sections for field in section.fields
    )
    request_data = bundle.request.model_dump(mode="json")
    request_data.update(
        base_release_id="release-9cb493e3-8d27-4a0f-8f29-93e2a078725b",
        base_activation_epoch=5,
        existing_definitions=[
            item.model_dump(mode="json") for item in bundle.compile_result.output.definitions
        ],
        existing_fields=[
            item.model_dump(mode="json") for item in bundle.compile_result.output.fields
        ],
        existing_pages=[
            item.model_dump(mode="json") for item in bundle.compile_result.output.pages
        ],
        existing_entity_versions=bundle.request.entity_versions,
        required_fields={entity_id: list(required) for entity_id in bundle.request.entity_versions},
        schema_identity="catalog:fixture",
        profile_identity="profile-set:fixture",
    )
    request = g2.CompileRequest.model_validate(request_data)
    fields = []
    for field in bundle.compile_result.output.fields:
        if field.field_key == "social_insurance_requirement":
            field = field.model_copy(update={"field_key": "social_insurance_requirements"})
            if tamper_unknown_reason and field.entity_id == "ping-an-e-sheng-bao":
                field = field.model_copy(update={"unknown_reason": "TAMPERED_BUT_STILL_UNKNOWN"})
        fields.append(field)
    audit = [
        g2.AuditDisposition(
            key=definition.concept_id,
            disposition="alias_link",
            reason="BASE_CARRYOVER",
        )
        for definition in bundle.compile_result.output.definitions
    ]
    audit.extend(
        g2.AuditDisposition(
            key=field.assertion_id,
            disposition="field_rule",
            reason="BASE_CARRYOVER",
        )
        for field in fields
    )
    audit.extend(
        g2.AuditDisposition(
            key=g2.free_page_id(page),
            disposition="alias_link",
            reason="BASE_CARRYOVER",
        )
        for page in bundle.compile_result.output.pages
    )
    output = bundle.compile_result.output.model_copy(
        update={
            "request_hash": request.request_hash,
            "fields": tuple(fields),
            "audit": tuple(sorted(audit, key=lambda item: item.key)),
        }
    )
    rows = tuple(json.loads(ALIGNMENTS.read_text())["alignments"])
    return request, output, rows


def test_unknown_alignment_rejects_changed_unknown_reason() -> None:
    request, output, rows = _aligned_output(tamper_unknown_reason=True)

    with pytest.raises(ValueError, match="BASE_UNKNOWN_KEY_MIGRATION_INELIGIBLE"):
        _current_alignment_validator()(request, output, rows)


def test_unknown_alignment_rejects_rehashed_false_member_digest() -> None:
    request, output, rows = _aligned_output(tamper_unknown_reason=False)
    contracts = importlib.import_module(
        "insurance_harness.knowledge_compiler.schema_wiki_contracts"
    )
    changed = dict(rows[0])
    changed["old_member_digest"] = "0" * 64
    changed["alignment_sha256"] = contracts.schema_wiki_sha256(
        changed["contract"],
        {key: value for key, value in changed.items() if key != "alignment_sha256"},
    )

    with pytest.raises(ValueError, match="BASE_UNKNOWN_KEY_MIGRATION_REQUIRED"):
        _current_alignment_validator()(request, output, (changed, rows[1]))


def test_g3_canonical_json_preserves_multiline_content() -> None:
    module = importlib.import_module(
        "insurance_harness.knowledge_compiler.batch_concept_compile_830_g3"
    )

    assert module._canonical_json({"body": "first\nsecond\tvalue\rline"}) == (
        '{"body":"first\\nsecond\\tvalue\\rline"}'
    )


def test_batch_candidate_rejects_duplicate_json_key() -> None:
    module = importlib.import_module(
        "insurance_harness.knowledge_compiler.batch_concept_compile_830_g3"
    )
    wire = G3_FIXTURE.read_text()
    duplicate = wire.replace(
        '{"admission":',
        '{"contract":"batch-concept-candidate-bundle.830.g3.v1","admission":',
        1,
    )

    with pytest.raises(module.BatchConceptCompileError, match="BATCH_CANDIDATE_INVALID"):
        module.validate_batch_candidate(duplicate)


def test_entity_binding_rejects_control_character_in_identity() -> None:
    module = importlib.import_module(
        "insurance_harness.knowledge_compiler.batch_concept_compile_830_g3"
    )
    bundle = module.validate_batch_candidate(G3_FIXTURE.read_bytes())
    changed = bundle.request.entity_bindings[0].model_dump(mode="json")
    changed["product_code"] = "18\t14"
    changed["binding_sha256"] = module._batch_sha256(
        changed["contract"],
        {key: value for key, value in changed.items() if key != "binding_sha256"},
    )

    with pytest.raises(ValueError):
        module.EntityCompileBinding830G3V1.model_validate(changed)


def test_actual342_fixture_round_trips_complete_base_and_registered_sources() -> None:
    module = importlib.import_module(
        "insurance_harness.knowledge_compiler.batch_concept_compile_830_g3"
    )
    wire = G3_FIXTURE.read_bytes()
    bundle = module.validate_batch_candidate(wire)
    base_bundle = _g2().CandidateBundle.model_validate_json(BASE_BUNDLE.read_bytes())
    request = bundle.request

    assert module._canonical_json(bundle).encode() == wire
    assert request.base_request.existing_definitions == (
        base_bundle.compile_result.output.definitions
    )
    assert request.base_request.existing_fields == base_bundle.compile_result.output.fields
    assert request.base_request.existing_pages == base_bundle.compile_result.output.pages
    assert request.base_request.existing_entity_versions == base_bundle.request.entity_versions
    assert len(request.base_request.existing_fields) == 134
    assert len(request.unknown_field_key_alignments) == 2
    assert len(bundle.model_compile_result.output.fields) == 208
    assert len(bundle.compile_result.output.fields) == 342
    assert len({field.assertion_id for field in bundle.compile_result.output.fields}) == 342
    assert {
        entry.receipt.contract for entry in request.resolution_inputs.corpus.entries
    } == {"knowledge-revision-source.v1"}
    assert len(request.base_request.sources) == 26
    assert len(wire) < 8 * 1024 * 1024


def test_builder_replays_c_and_reconstructs_exact_fixture_request() -> None:
    module = importlib.import_module(
        "insurance_harness.knowledge_compiler.batch_concept_compile_830_g3"
    )
    request = module.validate_batch_candidate(G3_FIXTURE.read_bytes()).request
    refs = tuple(
        sorted(
            (ref.material_id, ref.proposal_ref)
            for binding in request.entity_bindings
            for ref in binding.resolution_refs
        )
    )

    rebuilt = module.build_batch_compile_request(
        base_request=request.base_request,
        catalog_json=CATALOG.read_bytes(),
        profile_confirmation_json=(
            ROOT / "docs/insurance-kb/evidence/830-g3/profile-user-confirmation.json"
        ).read_bytes(),
        corpus=request.resolution_inputs.corpus,
        proposals=request.resolution_inputs.proposals,
        existing_entities=request.resolution_inputs.existing_entities,
        policy=request.resolution_inputs.policy,
        resolution=request.resolution,
        selected_decision_refs=refs,
    )

    assert rebuilt == request


def test_builder_rejects_missing_actual_base_match() -> None:
    module = importlib.import_module(
        "insurance_harness.knowledge_compiler.batch_concept_compile_830_g3"
    )
    request = module.validate_batch_candidate(G3_FIXTURE.read_bytes()).request
    refs = tuple(
        sorted(
            (ref.material_id, ref.proposal_ref)
            for binding in request.entity_bindings
            if binding.entity_id != "ping-an-e-sheng-bao-hui-xiang"
            for ref in binding.resolution_refs
        )
    )

    with pytest.raises(module.BatchConceptCompileError, match="BASE_ENTITY_MATCH_REQUIRED"):
        module.build_batch_compile_request(
            base_request=request.base_request,
            catalog_json=CATALOG.read_bytes(),
            profile_confirmation_json=(
                ROOT / "docs/insurance-kb/evidence/830-g3/profile-user-confirmation.json"
            ).read_bytes(),
            corpus=request.resolution_inputs.corpus,
            proposals=request.resolution_inputs.proposals,
            existing_entities=request.resolution_inputs.existing_entities,
            policy=request.resolution_inputs.policy,
            resolution=request.resolution,
            selected_decision_refs=refs,
        )


def test_composition_has_exact_alignment_and_independent_execution_raws() -> None:
    module = importlib.import_module(
        "insurance_harness.knowledge_compiler.batch_concept_compile_830_g3"
    )
    bundle = module.validate_batch_candidate(G3_FIXTURE.read_bytes())
    request = bundle.request
    aligned = module.aligned_existing_fields(request)
    old = {
        (field.entity_id, field.field_key): field
        for field in request.base_request.existing_fields
    }
    carried = {
        (field.entity_id, field.field_key): field
        for field in aligned
    }

    assert len(aligned) == 134
    assert sum(key[1] == "social_insurance_requirement" for key in old) == 2
    assert sum(key[1] == "social_insurance_requirements" for key in carried) == 2
    assert all(
        carried[key] == field
        for key, field in old.items()
        if key[1] != "social_insurance_requirement"
    )
    assert bundle.compile_result.execution.raw_output == module._canonical_json(
        bundle.compile_result.output
    )
    assert bundle.model_compile_result.execution.raw_output == module._canonical_json(
        bundle.model_compile_result.output
    )
    assert bundle.review_result.execution.raw_output == module._canonical_json(
        bundle.review_result.output
    )
    assert len(
        {
            bundle.model_compile_result.execution.run_id,
            bundle.compile_result.execution.run_id,
            bundle.review_result.execution.run_id,
        }
    ) == 3


def test_manifest_projects_all_field_payloads_and_profile_sections() -> None:
    module = importlib.import_module(
        "insurance_harness.knowledge_compiler.batch_concept_compile_830_g3"
    )
    bundle = module.validate_batch_candidate(G3_FIXTURE.read_bytes())
    field_members = {
        member.member_id: member
        for member in bundle.page_manifest.members
        if member.kind == "field_assertion"
    }
    overviews = [
        member
        for member in bundle.page_manifest.members
        if member.kind == "entity_overview"
    ]

    assert len(field_members) == 342
    assert all(
        field_members[field.assertion_id].payload == field.model_dump(mode="json")
        for field in bundle.compile_result.output.fields
    )
    assert len(overviews) == 5
    assert sorted(
        sum(len(section["fields"]) for section in member.payload["sections"])
        for member in overviews
    ) == [62, 67, 67, 67, 79]
    assert sorted(len(member.payload["sections"]) for member in overviews) == [7, 7, 7, 8, 8]


def test_actual342_preparation_post_capacity_receipt_matches_exact_bytes() -> None:
    module = importlib.import_module(
        "insurance_harness.knowledge_compiler.batch_concept_compile_830_g3"
    )
    post = G3_PREPARATION.read_bytes()
    payload = json.loads(post)
    provenance = json.loads(G3_PROVENANCE.read_bytes())

    assert module._canonical_json(payload).encode() == post
    assert payload["preparation_id"] == "fixture-g3-actual342"
    assert module.validate_batch_candidate(
        json.dumps(
            payload["batch_concept_candidate_bundle"],
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
        ).encode()
    ).candidate_hash
    assert provenance["fixture_counts"] == {
        "entities": 5,
        "fields": 342,
        "carried_fields": 132,
        "aligned_fields": 2,
        "delta_fields": 208,
        "source_blocks": 26,
    }
    assert provenance["preparation_post_bytes"] == len(post) == 2_247_500
    assert provenance["serialized_bytes"]["handler_limit"] == 8 * 1024 * 1024
    assert len(post) < provenance["serialized_bytes"]["handler_limit"]
