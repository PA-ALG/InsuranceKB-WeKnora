package types

import (
	"bytes"
	"os"
	"testing"

	"github.com/stretchr/testify/require"
)

const batchConceptFixture830G3 = "../../harness/tests/fixtures/batch_concept_compile_830_g3/candidate.json"
const batchConceptPreparation830G3 = "../../harness/tests/fixtures/batch_concept_compile_830_g3/preparation-request.json"

func TestParseBatchConceptCandidateBundle830G3ValidatesActual342Fixture(t *testing.T) {
	raw, err := os.ReadFile(batchConceptFixture830G3)
	require.NoError(t, err)
	var decoded BatchConceptCandidateBundle830G3
	require.NoError(t, decodeExactObject830G3(raw, &decoded, batchBundleKeys830G3, true))
	require.NoError(t, validateBatchRequest830G3(decoded.Request))
	require.NoError(t, validateDelta830G3(decoded.Request, decoded.ModelCompileResult.Output))

	bundle, canonical, err := CanonicalBatchConceptCandidateBundle830G3(raw)
	require.NoError(t, err)
	require.Equal(t, raw, canonical)
	require.Equal(t, "095c901c688bcc791af4a2dd0875e41045bc9b159567fde0e4dc85f3b06b667c", bundle.CandidateHash)
	require.Equal(t, "bd2354b1a3db98e9ce69704a0f6a6f1a6e261ec84dc4a7e63b1cd70732cd993a", bundle.Request.RequestSHA256)
	require.Len(t, bundle.Request.BaseRequest.ExistingFields, 134)
	require.Len(t, bundle.Request.UnknownFieldKeyAlignments, 2)
	require.Len(t, bundle.ModelCompileResult.Output.Fields, 208)
	require.Len(t, bundle.CompileResult.Output.Fields, 342)
	require.Len(t, bundle.PageManifest.Members, 354)
	require.Len(t, bundle.Request.BaseRequest.Sources, 26)
	for _, entry := range bundle.Request.ResolutionInputs.Corpus.Entries {
		require.Equal(t, "knowledge-revision-source.v1", entry.Receipt.Contract)
		require.NotNil(t, entry.Receipt.Registered)
		require.Nil(t, entry.Receipt.Legacy)
	}

	snapshots, err := bundle.SnapshotMembers()
	require.NoError(t, err)
	require.Len(t, snapshots, 354)
	for index, snapshot := range snapshots {
		require.Equal(t, bundle.PageManifest.Members[index].MemberID, snapshot.LogicalSlug)
		require.Equal(t, bundle.CandidateHash, snapshot.RevisionID)
		require.Regexp(t, "^[0-9a-f]{64}$", snapshot.MemberDigest)
	}
}

func TestBatchConceptCandidateBundle830G3RejectsAmbiguousWire(t *testing.T) {
	raw, err := os.ReadFile(batchConceptFixture830G3)
	require.NoError(t, err)
	tests := map[string][]byte{
		"duplicate top key": bytes.Replace(
			raw, []byte(`{"admission":`),
			[]byte(`{"contract":"batch-concept-candidate-bundle.830.g3.v1","admission":`), 1,
		),
		"unknown top key": bytes.Replace(
			raw, []byte(`{"admission":`), []byte(`{"unexpected":true,"admission":`), 1,
		),
		"unknown registered receipt": bytes.Replace(
			raw, []byte(`"contract":"knowledge-revision-source.v1"`),
			[]byte(`"contract":"unknown-source.v1"`), 1,
		),
		"binary float": bytes.Replace(
			raw, []byte(`"base_activation_epoch":5`), []byte(`"base_activation_epoch":5.0`), 1,
		),
	}
	for name, changed := range tests {
		t.Run(name, func(t *testing.T) {
			require.NotEqual(t, raw, changed)
			_, err := ParseBatchConceptCandidateBundle830G3(changed)
			require.ErrorIs(t, err, ErrConceptCandidateBundle830G3)
		})
	}
}

func TestBatchConceptCanonical830G3PreservesMultilineAndRejectsBadDomain(t *testing.T) {
	payload := map[string]any{"body": "first\nsecond\tvalue\rline"}
	digest, err := batchConceptHash830G3("batch-test.830.g3.v1", payload)
	require.NoError(t, err)
	require.Equal(t, "6fd2a4f372f2f7f93080180728eedacbd5cb00b349009241f1332760076efeef", digest)

	for _, domain := range []string{"", "批次", "bad\nkind"} {
		_, err := batchConceptHash830G3(domain, payload)
		require.ErrorIs(t, err, ErrConceptCandidateBundle830G3)
	}
}

func TestBatchConceptPreparationActual342FitsExistingEightMiBLimit(t *testing.T) {
	raw, err := os.ReadFile(batchConceptPreparation830G3)
	require.NoError(t, err)
	require.Equal(t, 2_247_500, len(raw))
	require.Less(t, len(raw), 8*1024*1024)
}
