package types

import (
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"os"
	"testing"

	"github.com/stretchr/testify/require"
)

func sha256Hex830G3(raw []byte) string {
	sum := sha256.Sum256(raw)
	return hex.EncodeToString(sum[:])
}

func fixtureMap830G3(t *testing.T) map[string]any {
	t.Helper()
	raw, err := os.ReadFile(batchConceptFixture830G3)
	require.NoError(t, err)
	decoder := json.NewDecoder(bytes.NewReader(raw))
	decoder.UseNumber()
	var value map[string]any
	require.NoError(t, decoder.Decode(&value))
	return value
}

func map830G3(t *testing.T, value any) map[string]any {
	t.Helper()
	result, ok := value.(map[string]any)
	require.True(t, ok)
	return result
}

func slice830G3(t *testing.T, value any) []any {
	t.Helper()
	result, ok := value.([]any)
	require.True(t, ok)
	return result
}

func rehashMap830G3(t *testing.T, value map[string]any, domain, field string) {
	t.Helper()
	delete(value, field)
	digest, err := batchConceptHash830G3(domain, value)
	require.NoError(t, err)
	value[field] = digest
}

func rehashCandidateMap830G3(t *testing.T, candidate map[string]any) []byte {
	t.Helper()
	request := map830G3(t, candidate["request"])
	inputs := map830G3(t, request["resolution_inputs"])
	proposals := map830G3(t, inputs["proposals"])
	for _, rawProposal := range slice830G3(t, proposals["proposals"]) {
		rehashMap830G3(t, map830G3(t, rawProposal), "material-proposal.830.g3.v1", "proposal_sha256")
	}
	rehashMap830G3(t, proposals, "batch-identity-proposals.830.g3.v1", "proposals_sha256")
	rehashMap830G3(t, inputs, "batch-resolution-inputs.830.g3.v1", "inputs_sha256")
	resolution := map830G3(t, request["resolution"])
	resolution["proposals_sha256"] = proposals["proposals_sha256"]
	rehashMap830G3(t, resolution, "batch-entity-resolution.830.g3.v1", "batch_sha256")
	rehashMap830G3(t, request, "batch-concept-compile-request.830.g3.v1", "request_sha256")

	baseRequest := map830G3(t, request["base_request"])
	var typedBaseRequest ConceptCompileRequest830G2
	baseRequestRaw, err := json.Marshal(baseRequest)
	require.NoError(t, err)
	require.NoError(t, json.Unmarshal(baseRequestRaw, &typedBaseRequest))
	baseRequestHash, err := compileRequestHash830G3(typedBaseRequest)
	require.NoError(t, err)
	modelResult := map830G3(t, candidate["model_compile_result"])
	modelExecution := map830G3(t, modelResult["execution"])
	compilerContext := map[string]any{
		"request": request, "request_sha256": request["request_sha256"],
		"base_request_hash": baseRequestHash, "output_mode": "NEW_MEMBERS_ONLY",
	}
	compilerContextHash, err := batchConceptHash830G3("batch-concept-compile-context.830.g3.v1", compilerContext)
	require.NoError(t, err)
	modelExecution["context_hash"] = compilerContextHash
	modelExecutionHash, err := batchConceptHash830G3("batch-concept-model-execution.830.g3.v1", modelExecution)
	require.NoError(t, err)
	var modelOutput ConceptCompileOutput830G2
	modelOutputRaw, err := json.Marshal(modelResult["output"])
	require.NoError(t, err)
	require.NoError(t, json.Unmarshal(modelOutputRaw, &modelOutput))
	modelOutputHash, err := compileOutputHash830G3(modelOutput)
	require.NoError(t, err)
	carryContextHash, err := batchConceptHash830G3("batch-concept-carry-context.830.g3.v1", map[string]any{
		"request_sha256":                 request["request_sha256"],
		"model_compile_output_hash":      modelOutputHash,
		"model_compile_execution_sha256": modelExecutionHash,
	})
	require.NoError(t, err)
	map830G3(t, map830G3(t, candidate["compile_result"])["execution"])["context_hash"] = carryContextHash
	var finalOutput ConceptCompileOutput830G2
	finalOutputRaw, err := json.Marshal(map830G3(t, candidate["compile_result"])["output"])
	require.NoError(t, err)
	require.NoError(t, json.Unmarshal(finalOutputRaw, &finalOutput))
	finalHash, err := compileOutputHash830G3(finalOutput)
	require.NoError(t, err)
	reviewContextHash, err := batchConceptHash830G3("batch-concept-review-context.830.g3.v1", map[string]any{
		"request": request, "candidate": map830G3(t, candidate["compile_result"])["output"],
		"request_sha256": request["request_sha256"], "base_request_hash": baseRequestHash,
		"output_hash": finalHash,
	})
	require.NoError(t, err)
	map830G3(t, map830G3(t, candidate["review_result"])["execution"])["context_hash"] = reviewContextHash
	rehashMap830G3(t, candidate, conceptBatchContract830G3, "candidate_hash")
	raw, err := json.Marshal(candidate)
	require.NoError(t, err)
	return raw
}

const batchConceptFixture830G3 = "../../harness/tests/fixtures/batch_concept_compile_830_g3/candidate.json"
const batchConceptPreparation830G3 = "../../harness/tests/fixtures/batch_concept_compile_830_g3/preparation-request.json"

func TestParseBatchConceptCandidateBundle830G3ValidatesActual342Fixture(t *testing.T) {
	raw, err := os.ReadFile(batchConceptFixture830G3)
	require.NoError(t, err)
	var decoded BatchConceptCandidateBundle830G3
	require.NoError(t, decodeExactObject830G3(raw, &decoded, batchBundleKeys830G3, true))
	require.NoError(t, validateBatchRequest830G3(decoded.Request))
	require.NoError(t, validateDelta830G3(decoded.Request, decoded.ModelCompileResult.Output))

	bundle, canonical, err := CanonicalBatchConceptCandidateBundle830G3(raw)
	require.NoError(t, err)
	require.Equal(t, raw, canonical)
	require.Equal(t, "e9f3fc9bec2cca609a30dce0f015a6af955e41da9d7a42399b05164efef14870", bundle.CandidateHash)
	require.Equal(t, "40920c09c42a9b28f1b8348c34d0bd9b63dde7568fc90c11311d554b7b6e25ec", bundle.Request.RequestSHA256)
	require.Len(t, bundle.Request.BaseRequest.ExistingFields, 134)
	require.Len(t, bundle.Request.UnknownFieldKeyAlignments, 2)
	require.Len(t, bundle.ModelCompileResult.Output.Fields, 208)
	require.Len(t, bundle.CompileResult.Output.Fields, 342)
	require.Len(t, bundle.PageManifest.Members, 354)
	require.Len(t, bundle.Request.BaseRequest.Sources, 27)
	for _, entry := range bundle.Request.ResolutionInputs.Corpus.Entries {
		require.Equal(t, "knowledge-revision-source.v1", entry.Receipt.Contract)
		require.NotNil(t, entry.Receipt.Registered)
		require.Nil(t, entry.Receipt.Legacy)
	}

	snapshots, err := bundle.SnapshotMembers()
	require.NoError(t, err)
	require.Len(t, snapshots, 354)
	for index, snapshot := range snapshots {
		require.Equal(t, bundle.PageManifest.Members[index].MemberID, snapshot.LogicalSlug)
		require.Equal(t, bundle.CandidateHash, snapshot.RevisionID)
		require.Regexp(t, "^[0-9a-f]{64}$", snapshot.MemberDigest)
	}
}

func TestBatchConceptRequest830G3ValidatesFrozenComponents(t *testing.T) {
	raw, err := os.ReadFile(batchConceptFixture830G3)
	require.NoError(t, err)
	var decoded BatchConceptCandidateBundle830G3
	require.NoError(t, decodeExactObject830G3(raw, &decoded, batchBundleKeys830G3, true))
	request := decoded.Request
	require.NoError(t, validateConceptRequest830G2(request.BaseRequest))
	catalogRaw, err := conceptCanonicalJSON830G2(request.Catalog)
	require.NoError(t, err)
	require.Equal(t, request.CatalogWireSHA256, sha256Hex830G3(catalogRaw))
	expectedCatalog, err := batchConceptHashWithout830G3(request.Catalog.Contract, request.Catalog, "catalog_sha256")
	require.NoError(t, err)
	require.Equal(t, request.Catalog.CatalogSHA256, expectedCatalog)
	for index, entry := range request.Catalog.Entries {
		expectedPack, hashErr := batchConceptHashWithout830G3(entry.Pack.Contract, entry.Pack, "schema_pack_sha256")
		require.NoError(t, hashErr, index)
		require.Equal(t, entry.Pack.SchemaPackSHA256, expectedPack, index)
		require.NoError(t, validateEntityPageProfile830G1(entry.Profile), index)
		for fieldIndex, field := range entry.Pack.Fields {
			metadata := map[string]any{
				"field_key": field.FieldKey, "short_title": field.ShortTitle,
				"schema_category": field.SchemaCategory, "value_spec": field.ValueSpec,
				"description": field.Description, "source_guidance": field.SourceGuidance,
				"formation_method": field.FormationMethod, "knowledge_role": field.KnowledgeRole,
				"common_field_marker":       field.CommonFieldMarker,
				"other_applicable_products": field.OtherApplicableProduct,
				"usage_frequency":           field.UsageFrequency,
			}
			expectedField, hashErr := batchConceptHash830G3(
				"schema-field-definition.830.g3.v1",
				map[string]any{"schema_pack_id": entry.Pack.SchemaPackID, "field": metadata},
			)
			require.NoError(t, hashErr, index, fieldIndex)
			require.Equal(t, field.SemanticSHA256, expectedField, index, fieldIndex)
		}
	}
	require.NoError(t, validateSchemaCatalog830G3(request.Catalog, request.CatalogWireSHA256))
	require.NoError(t, validateProfileConfirmation830G3(request.ProfileConfirmation, request.Catalog))
	require.NoError(t, validateBatchCorpus830G3(request.ResolutionInputs.Corpus))
	require.True(t, hashEqualWithout830G3(request.ResolutionInputs.Contract, request.ResolutionInputs, "inputs_sha256", request.ResolutionInputs.InputsSHA256))
	var proposalPayload map[string]any
	decoder := json.NewDecoder(bytes.NewReader(request.ResolutionInputs.Proposals))
	decoder.UseNumber()
	require.NoError(t, decoder.Decode(&proposalPayload))
	proposalActual := proposalPayload["proposals_sha256"].(string)
	delete(proposalPayload, "proposals_sha256")
	proposalExpected, err := batchConceptHash830G3("batch-identity-proposals.830.g3.v1", proposalPayload)
	require.NoError(t, err)
	require.Equal(t, proposalActual, proposalExpected)
	var decodedProposal map[string]any
	require.NoError(t, decodeExactObject830G3(request.ResolutionInputs.Proposals, &decodedProposal, proposalKeys830G3, true))
	_, err = validateRawContractHash830G3(request.ResolutionInputs.Proposals, "batch-identity-proposals.830.g3.v1", "proposals_sha256", proposalKeys830G3)
	require.NoError(t, err)
	_, err = validateRawContractHash830G3(request.ResolutionInputs.ExistingEntities, "existing-entities.830.g3.v1", "snapshot_sha256", existingKeys830G3)
	require.NoError(t, err)
	_, err = validateRawContractHash830G3(request.ResolutionInputs.Policy, "batch-resolution-policy.830.g3.v1", "policy_sha256", policyKeys830G3)
	require.NoError(t, err)
	_, _, _, err = validateResolutionInputs830G3(request.ResolutionInputs)
	require.NoError(t, err)
	var resolution batchResolutionSummary830G3
	require.NoError(t, decodeExactObject830G3(request.Resolution, &resolution, resolutionKeys830G3, true))
	require.True(t, hashEqualWithout830G3(resolution.Contract, resolution, "batch_sha256", resolution.BatchSHA256))
	var payload map[string]any
	require.NoError(t, json.Unmarshal(request.Resolution, &payload))
	require.NotEmpty(t, payload)
}

func TestBatchConceptCandidateBundle830G3RejectsAmbiguousWire(t *testing.T) {
	raw, err := os.ReadFile(batchConceptFixture830G3)
	require.NoError(t, err)
	tests := map[string][]byte{
		"duplicate top key": bytes.Replace(
			raw, []byte(`{"admission":`),
			[]byte(`{"contract":"batch-concept-candidate-bundle.830.g3.v1","admission":`), 1,
		),
		"unknown top key": bytes.Replace(
			raw, []byte(`{"admission":`), []byte(`{"unexpected":true,"admission":`), 1,
		),
		"unknown registered receipt": bytes.Replace(
			raw, []byte(`"contract":"knowledge-revision-source.v1"`),
			[]byte(`"contract":"unknown-source.v1"`), 1,
		),
		"binary float": bytes.Replace(
			raw, []byte(`"base_activation_epoch":5`), []byte(`"base_activation_epoch":5.0`), 1,
		),
	}
	for name, changed := range tests {
		t.Run(name, func(t *testing.T) {
			require.NotEqual(t, raw, changed)
			_, err := ParseBatchConceptCandidateBundle830G3(changed)
			require.ErrorIs(t, err, ErrConceptCandidateBundle830G3)
		})
	}
}

func TestBatchConceptCandidateBundle830G3RejectsRehashedProposalWithoutResolutionReplay(t *testing.T) {
	candidate := fixtureMap830G3(t)
	originalRaw, err := os.ReadFile(batchConceptFixture830G3)
	require.NoError(t, err)
	rehashedOriginal := rehashCandidateMap830G3(t, fixtureMap830G3(t))
	require.JSONEq(t, string(originalRaw), string(rehashedOriginal))
	_, err = ParseBatchConceptCandidateBundle830G3(rehashedOriginal)
	require.NoError(t, err)
	request := map830G3(t, candidate["request"])
	inputs := map830G3(t, request["resolution_inputs"])
	proposals := map830G3(t, inputs["proposals"])
	firstProposal := map830G3(t, slice830G3(t, proposals["proposals"])[0])
	firstEntity := map830G3(t, slice830G3(t, firstProposal["entities"])[0])
	firstEntity["name"] = "篡改后仍具合法格式的产品名称"

	_, err = ParseBatchConceptCandidateBundle830G3(rehashCandidateMap830G3(t, candidate))
	require.ErrorIs(t, err, ErrConceptCandidateBundle830G3)
}

func TestBatchConceptRequest830G3RequiresExactSelectedAndCarrySourceUnion(t *testing.T) {
	raw, err := os.ReadFile(batchConceptFixture830G3)
	require.NoError(t, err)
	var bundle BatchConceptCandidateBundle830G3
	require.NoError(t, decodeExactObject830G3(raw, &bundle, batchBundleKeys830G3, true))
	entries, _, err := corpusIndexes830G3(bundle.Request.ResolutionInputs.Corpus)
	require.NoError(t, err)
	require.NoError(t, validateRequestSourceClosure830G3(bundle.Request, entries))

	missing := bundle.Request
	missing.BaseRequest.Sources = append([]ConceptSourceBlock830G2(nil), missing.BaseRequest.Sources[1:]...)
	require.ErrorIs(t, validateRequestSourceClosure830G3(missing, entries), ErrConceptCandidateBundle830G3)

	extra := bundle.Request
	extra.BaseRequest.Sources = append([]ConceptSourceBlock830G2(nil), extra.BaseRequest.Sources...)
	extraSource := extra.BaseRequest.Sources[0]
	extraSource.RevisionID = "fixture-extra-revision"
	extraSource.BlockID = "fixture-extra-block"
	extra.BaseRequest.Sources = append(extra.BaseRequest.Sources, extraSource)
	require.ErrorIs(t, validateRequestSourceClosure830G3(extra, entries), ErrConceptCandidateBundle830G3)

	tamperedEntries := make(map[string]CorpusEntry830G3, len(entries))
	for key, entry := range entries {
		tamperedEntries[key] = entry
	}
	for key, entry := range tamperedEntries {
		if len(entry.Blocks) != 0 {
			entry.Blocks = append([]ConceptSourceBlock830G2(nil), entry.Blocks...)
			entry.Blocks[0].Text += "TAMPER"
			tamperedEntries[key] = entry
			break
		}
	}
	require.ErrorIs(t, validateRequestSourceClosure830G3(bundle.Request, tamperedEntries), ErrConceptCandidateBundle830G3)
}

func TestBatchConceptDelta830G3RejectsOtherOwnerOnlyEvidence(t *testing.T) {
	raw, err := os.ReadFile(batchConceptFixture830G3)
	require.NoError(t, err)
	var bundle BatchConceptCandidateBundle830G3
	require.NoError(t, decodeExactObject830G3(raw, &bundle, batchBundleKeys830G3, true))
	require.NoError(t, validateDeltaEvidence830G3(bundle.Request, bundle.ModelCompileResult.Output))
	var evidence ConceptEvidence830G2
	var sourceOwner string
	for _, field := range bundle.ModelCompileResult.Output.Fields {
		if len(field.Evidence) != 0 {
			evidence, sourceOwner = field.Evidence[0], field.EntityID
			break
		}
	}
	require.NotEmpty(t, sourceOwner)
	changed := bundle.ModelCompileResult.Output
	changed.Fields = append([]ConceptFieldAssertion830G2(nil), changed.Fields...)
	for index := range changed.Fields {
		if changed.Fields[index].EntityID != sourceOwner {
			changed.Fields[index].Evidence = []ConceptEvidence830G2{evidence}
			require.ErrorIs(t, validateDeltaEvidence830G3(bundle.Request, changed), ErrConceptCandidateBundle830G3)
			return
		}
	}
	t.Fatal("fixture lacks a second owner")
}

func TestBatchConceptBinding830G3RejectsResolutionFactDrift(t *testing.T) {
	raw, err := os.ReadFile(batchConceptFixture830G3)
	require.NoError(t, err)
	var bundle BatchConceptCandidateBundle830G3
	require.NoError(t, decodeExactObject830G3(raw, &bundle, batchBundleKeys830G3, true))
	typed, err := decodeResolutionInputs830G3(bundle.Request.ResolutionInputs, bundle.Request.Resolution)
	require.NoError(t, err)
	require.NoError(t, validateBindingsAgainstResolution830G3(bundle.Request, typed))
	changed := bundle.Request
	changed.EntityBindings = append([]EntityCompileBinding830G3(nil), changed.EntityBindings...)
	changed.EntityBindings[0].DisplayName = "合法格式但不对应C决策的名称"
	require.ErrorIs(t, validateBindingsAgainstResolution830G3(changed, typed), ErrConceptCandidateBundle830G3)
}

func TestBatchConceptCandidateBundle830G3RejectsRehashedBindingAndConfirmationDrift(t *testing.T) {
	tests := map[string]func(*testing.T, map[string]any){
		"binding display name": func(t *testing.T, candidate map[string]any) {
			request := map830G3(t, candidate["request"])
			binding := map830G3(t, slice830G3(t, request["entity_bindings"])[0])
			binding["display_name"] = "不对应所选C child的名称"
			rehashMap830G3(t, binding, "entity-compile-binding.830.g3.v1", "binding_sha256")
		},
		"fabricated confirmation actor": func(t *testing.T, candidate map[string]any) {
			request := map830G3(t, candidate["request"])
			confirmation := map830G3(t, request["profile_confirmation"])
			receipt := map830G3(t, confirmation["receipt"])
			receipt["actor"] = "fabricated-reviewer"
			digest, err := batchConceptHash830G3("830-g3-profile-user-confirmation.v1", receipt)
			require.NoError(t, err)
			confirmation["receipt_semantic_sha256"] = digest
		},
	}
	for name, mutate := range tests {
		t.Run(name, func(t *testing.T) {
			candidate := fixtureMap830G3(t)
			mutate(t, candidate)
			_, err := ParseBatchConceptCandidateBundle830G3(rehashCandidateMap830G3(t, candidate))
			require.ErrorIs(t, err, ErrConceptCandidateBundle830G3)
		})
	}
}

func TestBatchConceptTypedText830G3AllowsBodiesButRejectsStructuredControls(t *testing.T) {
	require.True(t, validBodyText830G3("第一行\n第二行\t值\r尾"))
	for _, value := range []string{"bad\nid", "bad\tid", "bad\rid", "bad\x7fid"} {
		require.False(t, validStructuredText830G3(value))
	}
	raw, err := os.ReadFile(batchConceptFixture830G3)
	require.NoError(t, err)
	var bundle BatchConceptCandidateBundle830G3
	require.NoError(t, decodeExactObject830G3(raw, &bundle, batchBundleKeys830G3, true))
	typed, err := decodeResolutionInputs830G3(bundle.Request.ResolutionInputs, bundle.Request.Resolution)
	require.NoError(t, err)
	receipt := typed.Proposals.ModelReceipts[0].PolicyReceipt
	receipt.RunID = "bad\nrun"
	require.ErrorIs(t, validatePolicyReceipt830G3(receipt), ErrConceptCandidateBundle830G3)
}

func TestBatchConceptCanonical830G3PreservesMultilineAndRejectsBadDomain(t *testing.T) {
	payload := map[string]any{"body": "first\nsecond\tvalue\rline"}
	digest, err := batchConceptHash830G3("batch-test.830.g3.v1", payload)
	require.NoError(t, err)
	require.Equal(t, "6fd2a4f372f2f7f93080180728eedacbd5cb00b349009241f1332760076efeef", digest)

	for _, domain := range []string{"", "批次", "bad\nkind"} {
		_, err := batchConceptHash830G3(domain, payload)
		require.ErrorIs(t, err, ErrConceptCandidateBundle830G3)
	}
}

func TestBatchConceptPreparationActual342FitsExistingEightMiBLimit(t *testing.T) {
	raw, err := os.ReadFile(batchConceptPreparation830G3)
	require.NoError(t, err)
	require.Equal(t, 2_254_490, len(raw))
	require.Less(t, len(raw), 8*1024*1024)
}
