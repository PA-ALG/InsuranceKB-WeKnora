package handler

import (
    "encoding/json"
    "testing"
    "github.com/stretchr/testify/require"
    "github.com/Tencent/WeKnora/internal/types"
)

func TestIndependentExistingCanonicalGuardRejectsReplacementInputs(t *testing.T) {
    invalid := append([]byte(`"bad`), byte(0xff)); invalid = append(invalid, []byte(`id"`)...)
    for _, raw := range [][]byte{invalid, []byte(`"bad\ud800id"`), []byte(`"bad\udc00id"`)} {
        _, err := types.CanonicalConceptMemberPayload830G2(json.RawMessage(raw))
        require.Error(t, err, "%q", raw)
    }
    for _, raw := range [][]byte{[]byte(`"emoji \ud83d\ude00"`), []byte(`"replacement �"`), []byte(`"escaped \ufffd"`), []byte(`"literal \\u2028"`)} {
        _, err := types.CanonicalConceptMemberPayload830G2(json.RawMessage(raw))
        require.NoError(t, err, "%q", raw)
    }
}
