package handler

import (
    "net/http"
    "testing"
    "github.com/stretchr/testify/assert"
)

func TestIndependentG3HandlerUnicodeDecodeBoundary(t *testing.T) {
    invalidByte := append([]byte(`{"preparation_id":"bad`), byte(0xff))
    invalidByte = append(invalidByte, []byte(`id","batch_concept_candidate_bundle":{"contract":"batch-concept-candidate-bundle.830.g3.v1"}}`)...)
    cases := []struct{name string; body []byte; want int; wantID string}{
        {"invalid UTF-8 byte", invalidByte, http.StatusBadRequest, ""},
        {"unpaired surrogate", []byte(`{"preparation_id":"bad\ud800id","batch_concept_candidate_bundle":{"contract":"batch-concept-candidate-bundle.830.g3.v1"}}`), http.StatusBadRequest, ""},
        {"literal replacement character", []byte(`{"preparation_id":"bad�id","batch_concept_candidate_bundle":{"contract":"batch-concept-candidate-bundle.830.g3.v1"}}`), http.StatusCreated, "bad�id"},
    }
    for _, tc := range cases {
        t.Run(tc.name, func(t *testing.T) {
            spy := &batchConceptHTTPServiceSpy830G3{schemaWikiHTTPServiceSpy: &schemaWikiHTTPServiceSpy{}}
            h := NewSchemaWikiHandler(nil, spy)
            c, recorder := batchConceptHTTPContext830G3(t, http.MethodPost, string(tc.body))
            h.CreateDraft(c)
            assert.Equal(t, tc.want, recorder.Code, recorder.Body.String())
            assert.Equal(t, tc.wantID, spy.preparationID, "wire identity must not be replaced by encoding/json")
        })
    }
}
