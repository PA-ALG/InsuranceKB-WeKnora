package service

import (
    "testing"
    "github.com/stretchr/testify/require"
    "github.com/Tencent/WeKnora/internal/types"
)

func TestIndependentG3LoadAndStoredPreparationIDClosure(t *testing.T) {
    fixture, schema, _ := batchConceptReleaseFixture830G3(t)
    invalid := []string{"   ", " leading", "trailing ", "bad\tvalue", "bad\nvalue", "bad\x7fvalue", "Cafe\u0301"}
    for _, id := range invalid {
        _, err := schema.LoadBatchConceptPreparation830G3(fixture.ctx, fixture.principal1, fixture.scope, id)
        require.ErrorIs(t, err, ErrSchemaWikiPreparationInvalid, "%q", id)
    }
    draft, err := schema.CreateBatchConceptDraft830G3(fixture.ctx, fixture.principal1, fixture.scope, "valid-stored-id", batchConceptCandidateVector830G3(t))
    require.NoError(t, err)
    corrupt := *draft
    corrupt.ID = "invalid\nstored"
    corrupt.PreparationDigest = digestWikiReleasePreparation(&corrupt)
    _, _, err = validateBatchConceptPreparation830G3(&corrupt, types.WikiReleasePreparationDraft, fixture.scope)
    require.ErrorIs(t, err, ErrSchemaWikiPreparationInvalid)
}
