package handler

import (
    "net/http"
    "testing"
    "github.com/stretchr/testify/require"
)

func TestIndependentG3HandlerRejectsInvalidUTF8PreparationIDBeforeReplacement(t *testing.T) {
    body := append([]byte(`{"preparation_id":"bad`), byte(0xff))
    body = append(body, []byte(`id","batch_concept_candidate_bundle":{"contract":"batch-concept-candidate-bundle.830.g3.v1"}}`)...)
    spy := &batchConceptHTTPServiceSpy830G3{schemaWikiHTTPServiceSpy: &schemaWikiHTTPServiceSpy{}}
    h := NewSchemaWikiHandler(nil, spy)
    c, recorder := batchConceptHTTPContext830G3(t, http.MethodPost, string(body))
    h.CreateDraft(c)
    require.Equal(t, http.StatusBadRequest, recorder.Code, recorder.Body.String())
    require.Empty(t, spy.preparationID, "invalid UTF-8 must be rejected before encoding/json replacement")
}
