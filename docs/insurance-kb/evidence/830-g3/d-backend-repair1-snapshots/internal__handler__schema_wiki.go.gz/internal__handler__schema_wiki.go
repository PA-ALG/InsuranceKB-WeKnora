package handler

import (
	"bytes"
	"context"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	stderrors "errors"
	"fmt"
	"io"
	"net/http"
	"strings"

	apprepo "github.com/Tencent/WeKnora/internal/application/repository"
	"github.com/Tencent/WeKnora/internal/application/service"
	"github.com/Tencent/WeKnora/internal/types"
	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
)

const schemaWikiResolvedHeadContextKey = "schema_wiki.resolved_head"

const maxSchemaWikiRequestBytes = 8 << 20

// SchemaWikiScopeResolver resolves the sole active Schema Wiki scope owned by
// a tenant Wiki KB. Implementations must fail closed on zero or multiple Heads.
type SchemaWikiScopeResolver interface {
	GetHeadForWikiKB(context.Context, uint64, string) (*types.WikiReleaseHead, error)
}

type schemaWikiPreparationScopeResolver interface {
	GetPreparationScopeForWikiKB(context.Context, uint64, string, string) (*types.WikiReleaseScope, error)
}

type SchemaWikiCitationContentRouteAuthorityResolver interface {
	ResolveSchemaCitationContentRouteAuthority(
		context.Context, string,
	) (*service.SchemaWikiCitationContentRouteAuthorityV1, error)
}

type schemaWikiFormalCandidatePreviewHTTPService interface {
	ReadSchemaWikiFormalCandidatePreview(
		context.Context,
		uint64,
		apprepo.SchemaWikiFormalCandidatePreviewKey,
	) (*service.SchemaWikiFormalCandidatePreviewResponseV1, error)
	ReadSchemaWikiFormalCandidatePreviewContent(
		context.Context,
		uint64,
		apprepo.SchemaWikiFormalCandidatePreviewKey,
		apprepo.SchemaWikiFormalCandidatePreviewContentRequest,
	) ([]byte, error)
}

type schemaWikiFormalCandidateDecisionHTTPService interface {
	DecideSchemaWikiFormalCandidatePreview(
		context.Context,
		types.WikiReleasePrincipal,
		types.WikiReleaseScope,
		apprepo.SchemaWikiFormalCandidatePreviewKey,
		[]byte,
		[]byte,
	) (*types.HumanBatchDecisionReceiptV1, *types.WikiReleaseReceipt, error)
}

type schemaWikiHTTPService interface {
	CreateEntityPageGraphDraft830G1(
		context.Context,
		types.WikiReleasePrincipal,
		types.WikiReleaseScope,
		string,
		json.RawMessage,
	) (*types.WikiReleasePreparation, error)
	CreateSchemaDraft(
		context.Context,
		types.WikiReleasePrincipal,
		types.WikiReleaseScope,
		string,
		types.KnowledgeWikiReleaseV1,
		types.Schema67CandidateEvidenceAuthorityV1,
		types.SchemaWikiReviewBundleV1,
		types.Schema67GoldenEvaluationReviewBundleV1,
		types.Schema67GoldenReviewSuccessorMetadataV1,
	) (*types.WikiReleasePreparation, error)
	ReviewSchemaDraft(
		context.Context,
		types.WikiReleasePrincipal,
		types.WikiReleaseScope,
		string,
		[]byte,
	) (*types.WikiReleasePreparation, error)
	ReadSchemaDraftMember(
		context.Context,
		types.WikiReleasePrincipal,
		types.WikiReleaseScope,
		string,
		string,
		string,
	) (*types.WikiReleaseMemberSnapshot, error)
	ReadCurrentSchemaMember(
		context.Context,
		types.WikiReleasePrincipal,
		types.WikiReleaseScope,
		string,
	) (*service.SchemaWikiMemberReadV1, error)
	SearchCurrentSchemaMembers(
		context.Context,
		types.WikiReleasePrincipal,
		types.WikiReleaseScope,
		string,
	) ([]service.SchemaWikiMemberReadV1, error)
	ReadCurrentSchemaAuthority(
		context.Context,
		types.WikiReleasePrincipal,
		types.WikiReleaseScope,
	) (*service.SchemaWikiCurrentAuthorityV1, error)
	ReadReviewedPreparationMember(
		context.Context,
		types.WikiReleasePrincipal,
		types.WikiReleaseScope,
		string,
		string,
	) (*service.SchemaWikiMemberReadV1, error)
	ReadSchemaPreparationMember(
		context.Context,
		types.WikiReleasePrincipal,
		types.WikiReleaseScope,
		string,
		string,
	) (*service.SchemaWikiMemberReadV1, error)
	ReadReviewedPreparationRoot(
		context.Context,
		types.WikiReleasePrincipal,
		types.WikiReleaseScope,
		string,
	) (*types.SchemaRootPageV1, error)
	ReadCurrentSchemaCitation(
		context.Context,
		types.WikiReleasePrincipal,
		types.WikiReleaseScope,
		string,
		string,
		string,
	) ([]byte, error)
	IssueCurrentSchemaCitationAuthority(
		context.Context,
		types.WikiReleasePrincipal,
		types.WikiReleaseScope,
		string,
		string,
		string,
	) (*types.SchemaWikiCitationContentAuthorityV1, error)
	IssueEntityPageGraphPreparationCitationAuthority830G1(
		context.Context,
		types.WikiReleasePrincipal,
		types.WikiReleaseScope,
		string,
		string,
		string,
		string,
	) (*types.SchemaWikiCitationContentAuthorityV1, error)
	ReadSchemaCitationContent(
		context.Context,
		types.WikiReleasePrincipal,
		types.WikiReleaseScope,
		string,
	) ([]byte, error)
	ReadReviewedPreparationCitation(
		context.Context,
		types.WikiReleasePrincipal,
		types.WikiReleaseScope,
		string,
		string,
		string,
	) ([]byte, error)
	ReadSchemaPreparationGoldenQualitySummary(
		context.Context,
		types.WikiReleasePrincipal,
		types.WikiReleaseScope,
		string,
		string,
	) (*types.SchemaWikiGoldenQualitySummaryV1, error)
	ReadSchemaPreparationGoldenQualityDossier(
		context.Context,
		types.WikiReleasePrincipal,
		types.WikiReleaseScope,
		string,
		string,
	) (*types.SchemaWikiGoldenQualityDossierV2, error)
	IssueSchemaPreparationGoldenEvidencePreview(
		context.Context,
		types.WikiReleasePrincipal,
		types.WikiReleaseScope,
		string,
		string,
		string,
		string,
	) (*types.SchemaWikiGoldenEvidencePreviewAuthorityV1, error)
	ReadSchemaWikiGoldenSuccessorStatus(
		context.Context,
		types.WikiReleasePrincipal,
		types.WikiReleaseScope,
	) (*types.SchemaWikiGoldenSuccessorStatusV1, error)
}

// SchemaWikiHandler exposes the bounded Schema Wiki HTTP facade. Release and
// citation authority stays inside SchemaWikiService; HTTP callers provide only
// path identities and never custody DTOs.
type SchemaWikiHandler struct {
	scopeResolver           SchemaWikiScopeResolver
	schemaService           schemaWikiHTTPService
	citationRouteAuthority  SchemaWikiCitationContentRouteAuthorityResolver
	formalCandidatePreview  schemaWikiFormalCandidatePreviewHTTPService
	formalCandidateDecision schemaWikiFormalCandidateDecisionHTTPService
}

// NewSchemaWikiHandler constructs the explicitly injected Schema Wiki facade.
func NewSchemaWikiHandler(
	scopeResolver SchemaWikiScopeResolver,
	schemaService schemaWikiHTTPService,
	citationResolvers ...SchemaWikiCitationContentRouteAuthorityResolver,
) *SchemaWikiHandler {
	handler := &SchemaWikiHandler{scopeResolver: scopeResolver, schemaService: schemaService}
	if len(citationResolvers) == 1 {
		handler.citationRouteAuthority = citationResolvers[0]
	} else if resolver, ok := schemaService.(SchemaWikiCitationContentRouteAuthorityResolver); ok {
		handler.citationRouteAuthority = resolver
	}
	if preview, ok := schemaService.(schemaWikiFormalCandidatePreviewHTTPService); ok {
		handler.formalCandidatePreview = preview
	}
	if decision, ok := schemaService.(schemaWikiFormalCandidateDecisionHTTPService); ok {
		handler.formalCandidateDecision = decision
	}
	return handler
}

func schemaWikiFormalCandidatePreviewKeyFromParams(c *gin.Context) apprepo.SchemaWikiFormalCandidatePreviewKey {
	if c == nil {
		return apprepo.SchemaWikiFormalCandidatePreviewKey{}
	}
	return apprepo.SchemaWikiFormalCandidatePreviewKey{
		KBID: strings.TrimSpace(c.Param("kb_id")), ExperimentID: strings.TrimSpace(c.Param("experiment_id")),
		VersionIdentity: strings.TrimSpace(c.Param("version_identity")),
	}
}

func (h *SchemaWikiHandler) ReadFormalCandidatePreview(c *gin.Context) {
	tenantID, key, err := h.formalCandidatePreviewRequest(c)
	if err != nil {
		writeSchemaWikiError(c, err)
		return
	}
	response, err := h.formalCandidatePreview.ReadSchemaWikiFormalCandidatePreview(
		c.Request.Context(), tenantID, key,
	)
	if err != nil || response == nil {
		if err == nil {
			err = service.ErrSchemaWikiFormalCandidatePreviewBindingMismatch
		}
		writeSchemaWikiError(c, err)
		return
	}
	c.JSON(http.StatusOK, gin.H{"success": true, "data": response})
}

func (h *SchemaWikiHandler) ReadFormalCandidatePreviewContent(c *gin.Context) {
	tenantID, key, err := h.formalCandidatePreviewRequest(c)
	if err != nil {
		writeSchemaWikiError(c, err)
		return
	}
	request := apprepo.SchemaWikiFormalCandidatePreviewContentRequest{
		FieldID:     strings.TrimSpace(c.Param("field_id")),
		SelectionID: strings.TrimSpace(c.Param("selection_id")),
	}
	if request.FieldID == "" || request.SelectionID == "" {
		writeSchemaWikiError(c, service.ErrSchemaWikiFormalCandidatePreviewRequestInvalid)
		return
	}
	content, err := h.formalCandidatePreview.ReadSchemaWikiFormalCandidatePreviewContent(
		c.Request.Context(), tenantID, key, request,
	)
	if err != nil || len(content) == 0 {
		if err == nil {
			err = service.ErrSchemaWikiFormalCandidatePreviewBindingMismatch
		}
		writeSchemaWikiError(c, err)
		return
	}
	c.Data(http.StatusOK, "application/pdf", content)
}

func (h *SchemaWikiHandler) formalCandidatePreviewRequest(
	c *gin.Context,
) (uint64, apprepo.SchemaWikiFormalCandidatePreviewKey, error) {
	if h == nil || h.formalCandidatePreview == nil || c == nil || c.Request == nil ||
		c.Request.URL.RawQuery != "" || c.Request.ContentLength != 0 {
		return 0, apprepo.SchemaWikiFormalCandidatePreviewKey{}, service.ErrSchemaWikiFormalCandidatePreviewRequestInvalid
	}
	tenantValue, exists := c.Get(types.TenantIDContextKey.String())
	tenantID, ok := tenantValue.(uint64)
	key := schemaWikiFormalCandidatePreviewKeyFromParams(c)
	if !exists || !ok || tenantID == 0 || key.KBID == "" || key.ExperimentID == "" ||
		!validSchemaWikiC5HandlerSHA256(key.VersionIdentity) {
		return 0, apprepo.SchemaWikiFormalCandidatePreviewKey{}, service.ErrSchemaWikiFormalCandidatePreviewRequestInvalid
	}
	return tenantID, key, nil
}

func validSchemaWikiC5HandlerSHA256(value string) bool {
	if len(value) != 64 || value != strings.ToLower(value) {
		return false
	}
	_, err := hex.DecodeString(value)
	return err == nil
}

// DecideFormalCandidatePreview wires the one bounded human decision action to
// the existing C6 service. The path supplies only the exact C5 identity; raw
// decision and authorization values are forwarded byte-for-byte.
func (h *SchemaWikiHandler) DecideFormalCandidatePreview(c *gin.Context) {
	if h == nil || h.formalCandidateDecision == nil || c == nil || c.Request == nil ||
		c.Request.URL.RawQuery != "" {
		writeSchemaWikiError(c, service.ErrSchemaWikiFormalCandidatePreviewRequestInvalid)
		return
	}
	principal, scope, err := (&WikiReleaseHandler{}).requestIdentity(c)
	if err != nil {
		writeSchemaWikiError(c, err)
		return
	}
	experimentID := c.Param("experiment_id")
	versionIdentity := c.Param("version_identity")
	parsedExperimentID, parseErr := uuid.Parse(experimentID)
	if parseErr != nil || parsedExperimentID.String() != experimentID ||
		!validSchemaWikiC5HandlerSHA256(versionIdentity) {
		writeSchemaWikiError(c, service.ErrSchemaWikiFormalCandidatePreviewRequestInvalid)
		return
	}
	request, err := decodeSchemaWikiC6DecisionRequest(c)
	if err != nil {
		writeSchemaWikiError(c, err)
		return
	}
	decision, receipt, err := h.formalCandidateDecision.DecideSchemaWikiFormalCandidatePreview(
		c.Request.Context(), principal, scope,
		apprepo.SchemaWikiFormalCandidatePreviewKey{
			KBID: scope.RawKBID, ExperimentID: experimentID, VersionIdentity: versionIdentity,
		},
		request.HumanDecision,
		request.PublishAuthorization,
	)
	if err != nil {
		writeSchemaWikiError(c, err)
		return
	}
	if decision == nil {
		writeSchemaWikiError(c, service.ErrSchemaWikiFormalCandidatePreviewBindingMismatch)
		return
	}
	switch decision.Decision {
	case "reject":
		if receipt != nil {
			writeSchemaWikiError(c, service.ErrSchemaWikiFormalCandidatePreviewBindingMismatch)
			return
		}
		c.JSON(http.StatusOK, gin.H{"success": true, "data": decision})
	case "approve":
		if receipt == nil {
			writeSchemaWikiError(c, service.ErrSchemaWikiFormalCandidatePreviewBindingMismatch)
			return
		}
		c.JSON(http.StatusOK, gin.H{"success": true, "data": receipt})
	default:
		writeSchemaWikiError(c, service.ErrSchemaWikiFormalCandidatePreviewBindingMismatch)
	}
}

func decodeSchemaWikiC6DecisionRequest(c *gin.Context) (wikiReleaseActivationRequest, error) {
	var request wikiReleaseActivationRequest
	if c == nil || c.Request == nil || c.Request.Body == nil {
		return request, service.ErrSchemaWikiFormalCandidatePreviewRequestInvalid
	}
	decoder := json.NewDecoder(io.LimitReader(c.Request.Body, 2*maxWikiReleaseAuthorizationBytes+1))
	opening, err := decoder.Token()
	if err != nil || opening != json.Delim('{') {
		return request, service.ErrSchemaWikiFormalCandidatePreviewRequestInvalid
	}
	seen := map[string]struct{}{}
	for decoder.More() {
		fieldToken, fieldErr := decoder.Token()
		field, ok := fieldToken.(string)
		if fieldErr != nil || !ok {
			return request, service.ErrSchemaWikiFormalCandidatePreviewRequestInvalid
		}
		if _, duplicate := seen[field]; duplicate {
			return request, service.ErrSchemaWikiFormalCandidatePreviewRequestInvalid
		}
		seen[field] = struct{}{}
		switch field {
		case "human_decision":
			err = decoder.Decode(&request.HumanDecision)
		case "publish_authorization":
			err = decoder.Decode(&request.PublishAuthorization)
		default:
			return request, service.ErrSchemaWikiFormalCandidatePreviewRequestInvalid
		}
		if err != nil {
			return request, service.ErrSchemaWikiFormalCandidatePreviewRequestInvalid
		}
	}
	closing, err := decoder.Token()
	if err != nil || closing != json.Delim('}') || ensureWikiReleaseJSONEOF(decoder) != nil ||
		len(seen) != 2 || len(request.HumanDecision) == 0 || len(request.PublishAuthorization) == 0 ||
		len(request.HumanDecision) > maxWikiReleaseAuthorizationBytes ||
		len(request.PublishAuthorization) > maxWikiReleaseAuthorizationBytes {
		return wikiReleaseActivationRequest{}, service.ErrSchemaWikiFormalCandidatePreviewRequestInvalid
	}
	return request, nil
}

type schemaWikiCreateDraftRequest struct {
	PreparationID               string                                        `json:"preparation_id"`
	Release                     types.KnowledgeWikiReleaseV1                  `json:"release"`
	CandidateEvidenceAuthority  types.Schema67CandidateEvidenceAuthorityV1    `json:"candidate_evidence_authority"`
	ReviewBundle                types.SchemaWikiReviewBundleV1                `json:"review_bundle"`
	EvaluationBundle            types.Schema67GoldenEvaluationReviewBundleV1  `json:"evaluation_bundle"`
	ReviewSuccessor             types.Schema67GoldenReviewSuccessorMetadataV1 `json:"review_successor"`
	EntityPageManifest          json.RawMessage                               `json:"entity_page_manifest,omitempty"`
	ConceptCandidateBundle      json.RawMessage                               `json:"concept_candidate_bundle,omitempty"`
	BatchConceptCandidateBundle json.RawMessage                               `json:"batch_concept_candidate_bundle,omitempty"`
}

type schemaWikiReviewDraftRequest struct {
	HumanDecision json.RawMessage `json:"human_decision"`
}

type schemaWikiScopeV1 struct {
	Version     string `json:"version"`
	SpaceID     string `json:"space_id"`
	RawKBID     string `json:"raw_kb_id"`
	WikiKBID    string `json:"wiki_kb_id"`
	ScopeSHA256 string `json:"scope_sha256"`
}

type schemaWikiCurrentEntityVersionV1 struct {
	Version         string                 `json:"version"`
	EntityID        string                 `json:"entity_id"`
	EntityVersionID string                 `json:"entity_version_id"`
	ActiveReleaseID string                 `json:"active_release_id"`
	ActivationEpoch uint64                 `json:"activation_epoch"`
	Root            types.SchemaRootPageV1 `json:"root"`
}

// ResolveScopeParams derives non-overridable Space/RAW scope from the sole
// active Head. It is used only by the unscoped Wiki bootstrap route.
func (h *SchemaWikiHandler) ResolveScopeParams() gin.HandlerFunc {
	return func(c *gin.Context) {
		if strings.TrimSpace(c.Param("space_id")) != "" ||
			strings.TrimSpace(c.Param("raw_kb_id")) != "" {
			writeSchemaWikiError(c, service.ErrWikiReleaseAccessDenied)
			c.Abort()
			return
		}
		head, err := h.resolveHead(c)
		if err != nil {
			writeSchemaWikiError(c, err)
			c.Abort()
			return
		}
		c.Params = append(c.Params,
			gin.Param{Key: "space_id", Value: head.SpaceID},
			gin.Param{Key: "raw_kb_id", Value: head.RawKBID},
		)
		c.Set(schemaWikiResolvedHeadContextKey, *head)
		c.Next()
	}
}

// ResolvePreparationScopeParams derives a Draft/Ready scope without consulting
// Head. It is used only by the human-admin Candidate Preview bootstrap.
func (h *SchemaWikiHandler) ResolvePreparationScopeParams() gin.HandlerFunc {
	return func(c *gin.Context) {
		tenantValue, exists := c.Get(types.TenantIDContextKey.String())
		tenantID, tenantOK := tenantValue.(uint64)
		wikiKBID := strings.TrimSpace(c.Param("kb_id"))
		preparationID := strings.TrimSpace(c.Param("preparation_id"))
		resolver, resolverOK := h.scopeResolver.(schemaWikiPreparationScopeResolver)
		if !exists || !tenantOK || tenantID == 0 || wikiKBID == "" || preparationID == "" ||
			!resolverOK || strings.TrimSpace(c.Param("space_id")) != "" ||
			strings.TrimSpace(c.Param("raw_kb_id")) != "" {
			writeSchemaWikiError(c, service.ErrWikiReleaseAccessDenied)
			c.Abort()
			return
		}
		scope, err := resolver.GetPreparationScopeForWikiKB(
			c.Request.Context(), tenantID, wikiKBID, preparationID,
		)
		if err != nil || scope == nil || scope.TenantID != tenantID ||
			scope.WikiKBID != wikiKBID || strings.TrimSpace(scope.SpaceID) == "" ||
			strings.TrimSpace(scope.RawKBID) == "" {
			writeSchemaWikiError(c, service.ErrWikiReleaseAccessDenied)
			c.Abort()
			return
		}
		c.Params = append(c.Params,
			gin.Param{Key: "space_id", Value: scope.SpaceID},
			gin.Param{Key: "raw_kb_id", Value: scope.RawKBID},
		)
		c.Next()
	}
}

// RequireScopeParams re-resolves the active Head and proves that a scoped URL
// carries exactly the server-owned Space/RAW identities. It never rewrites a
// caller path and therefore cannot turn an unrelated allow-listed RAW KB into
// Schema authority.
func (h *SchemaWikiHandler) RequireScopeParams() gin.HandlerFunc {
	return func(c *gin.Context) {
		head, err := h.resolveHead(c)
		if err != nil || strings.TrimSpace(c.Param("space_id")) != head.SpaceID ||
			strings.TrimSpace(c.Param("raw_kb_id")) != head.RawKBID {
			writeSchemaWikiError(c, service.ErrWikiReleaseAccessDenied)
			c.Abort()
			return
		}
		c.Set(schemaWikiResolvedHeadContextKey, *head)
		c.Next()
	}
}

// RequireCitationContentScope verifies the opaque token before RAW ACL. The
// caller path may identify the Wiki KB for its first ACL only; Space/RAW must
// match the signed token and, for preparation tokens, immutable preparation
// custody. Active reads also re-resolve Head here and are pinned again before
// bytes open in the service.
func (h *SchemaWikiHandler) RequireCitationContentScope() gin.HandlerFunc {
	return func(c *gin.Context) {
		tenantID, wikiKBID, pathScope, ok := schemaWikiPathScope(c)
		if !ok || h == nil || h.scopeResolver == nil || h.citationRouteAuthority == nil {
			writeSchemaWikiError(c, service.ErrWikiReleaseAccessDenied)
			c.Abort()
			return
		}
		authority, err := h.citationRouteAuthority.ResolveSchemaCitationContentRouteAuthority(
			c.Request.Context(), strings.TrimSpace(c.Param("token")),
		)
		if err != nil || authority == nil || authority.Scope != pathScope ||
			authority.Scope.TenantID != tenantID || authority.Scope.WikiKBID != wikiKBID {
			writeSchemaWikiError(c, service.ErrWikiReleaseAccessDenied)
			c.Abort()
			return
		}
		switch authority.Kind {
		case "active":
			head, headErr := h.scopeResolver.GetHeadForWikiKB(c.Request.Context(), tenantID, wikiKBID)
			if headErr != nil || head == nil || head.WikiReleaseScope != authority.Scope {
				writeSchemaWikiError(c, service.ErrWikiReleaseAccessDenied)
				c.Abort()
				return
			}
			c.Set(schemaWikiResolvedHeadContextKey, *head)
		case "release":
			releaseID := strings.TrimSpace(authority.ReleaseID)
			if releaseID == "" || releaseID != authority.ReleaseID ||
				strings.EqualFold(releaseID, "current") || strings.EqualFold(releaseID, "latest") {
				writeSchemaWikiError(c, service.ErrWikiReleaseAccessDenied)
				c.Abort()
				return
			}
		case "preparation":
			principal, principalOK := types.PrincipalFromContext(c.Request.Context())
			_, apiKey := types.TenantAPIKeyScopeFromContext(c.Request.Context())
			if apiKey || !principalOK || principal.Type != types.PrincipalWebUser ||
				!types.TenantRoleFromContext(c.Request.Context()).HasPermission(types.TenantRoleAdmin) {
				writeSchemaWikiError(c, service.ErrWikiReleaseAccessDenied)
				c.Abort()
				return
			}
			resolver, resolverOK := h.scopeResolver.(schemaWikiPreparationScopeResolver)
			if !resolverOK || strings.TrimSpace(authority.PreparationID) == "" {
				writeSchemaWikiError(c, service.ErrWikiReleaseAccessDenied)
				c.Abort()
				return
			}
			stored, scopeErr := resolver.GetPreparationScopeForWikiKB(
				c.Request.Context(), tenantID, wikiKBID, authority.PreparationID,
			)
			if scopeErr != nil || stored == nil || *stored != authority.Scope {
				writeSchemaWikiError(c, service.ErrWikiReleaseAccessDenied)
				c.Abort()
				return
			}
		default:
			writeSchemaWikiError(c, service.ErrWikiReleaseAccessDenied)
			c.Abort()
			return
		}
		c.Next()
	}
}

// BindCreateScopeParams allows the initial no-Head Draft while refusing a
// path that conflicts with an already active Head. Scope remains path-only;
// the closed request body has no scope fields.
func (h *SchemaWikiHandler) BindCreateScopeParams() gin.HandlerFunc {
	return func(c *gin.Context) {
		tenantID, wikiKBID, scope, ok := schemaWikiPathScope(c)
		if !ok || h == nil || h.scopeResolver == nil {
			writeSchemaWikiError(c, service.ErrWikiReleaseAccessDenied)
			c.Abort()
			return
		}
		head, err := h.scopeResolver.GetHeadForWikiKB(c.Request.Context(), tenantID, wikiKBID)
		switch {
		case err == nil:
			if head == nil || head.WikiReleaseScope != scope {
				writeSchemaWikiError(c, service.ErrWikiReleaseAccessDenied)
				c.Abort()
				return
			}
		case stderrors.Is(err, apprepo.ErrWikiReleaseNotFound):
			// Initial Draft: no active Head is expected and the sealed path is
			// the only scope input.
		default:
			writeSchemaWikiError(c, service.ErrWikiReleaseAccessDenied)
			c.Abort()
			return
		}
		c.Next()
	}
}

// RequirePreparationScopeParams resolves Draft/Ready scope from the immutable
// preparation identity before RAW authorization. It never depends on Head.
func (h *SchemaWikiHandler) RequirePreparationScopeParams() gin.HandlerFunc {
	return func(c *gin.Context) {
		tenantID, wikiKBID, pathScope, ok := schemaWikiPathScope(c)
		resolver, resolverOK := h.scopeResolver.(schemaWikiPreparationScopeResolver)
		preparationID := strings.TrimSpace(c.Param("preparation_id"))
		if !ok || !resolverOK || preparationID == "" {
			writeSchemaWikiError(c, service.ErrWikiReleaseAccessDenied)
			c.Abort()
			return
		}
		storedScope, err := resolver.GetPreparationScopeForWikiKB(
			c.Request.Context(), tenantID, wikiKBID, preparationID,
		)
		if err != nil || storedScope == nil || *storedScope != pathScope {
			writeSchemaWikiError(c, service.ErrWikiReleaseAccessDenied)
			c.Abort()
			return
		}
		c.Next()
	}
}

func schemaWikiPathScope(c *gin.Context) (uint64, string, types.WikiReleaseScope, bool) {
	if c == nil || c.Request == nil {
		return 0, "", types.WikiReleaseScope{}, false
	}
	tenantValue, exists := c.Get(types.TenantIDContextKey.String())
	tenantID, tenantOK := tenantValue.(uint64)
	wikiKBID := strings.TrimSpace(c.Param("kb_id"))
	scope := types.WikiReleaseScope{
		TenantID: tenantID, SpaceID: strings.TrimSpace(c.Param("space_id")),
		RawKBID: strings.TrimSpace(c.Param("raw_kb_id")), WikiKBID: wikiKBID,
	}
	ok := exists && tenantOK && tenantID != 0 && wikiKBID != "" &&
		scope.SpaceID != "" && scope.RawKBID != ""
	return tenantID, wikiKBID, scope, ok
}

func (h *SchemaWikiHandler) resolveHead(c *gin.Context) (*types.WikiReleaseHead, error) {
	if h == nil || h.scopeResolver == nil || c == nil || c.Request == nil {
		return nil, service.ErrWikiReleaseAccessDenied
	}
	tenantValue, exists := c.Get(types.TenantIDContextKey.String())
	tenantID, ok := tenantValue.(uint64)
	wikiKBID := strings.TrimSpace(c.Param("kb_id"))
	if !exists || !ok || tenantID == 0 || wikiKBID == "" {
		return nil, service.ErrWikiReleaseAccessDenied
	}
	head, err := h.scopeResolver.GetHeadForWikiKB(c.Request.Context(), tenantID, wikiKBID)
	if err != nil {
		if stderrors.Is(err, apprepo.ErrWikiReleaseNotFound) ||
			stderrors.Is(err, apprepo.ErrWikiReleaseConflict) {
			return nil, service.ErrWikiReleaseAccessDenied
		}
		return nil, service.ErrWikiReleaseAccessDenied
	}
	if head == nil || head.TenantID != tenantID || head.WikiKBID != wikiKBID ||
		strings.TrimSpace(head.SpaceID) == "" || strings.TrimSpace(head.RawKBID) == "" ||
		strings.TrimSpace(head.ActiveReleaseID) == "" || head.ActivationEpoch == 0 {
		return nil, service.ErrWikiReleaseAccessDenied
	}
	return head, nil
}

// Scope returns only the closed, server-derived active scope after both KB
// access checks and the existing release access seal have succeeded.
func (h *SchemaWikiHandler) Scope(c *gin.Context) {
	value, ok := c.Get(schemaWikiResolvedHeadContextKey)
	head, typeOK := value.(types.WikiReleaseHead)
	if !ok || !typeOK {
		writeSchemaWikiError(c, service.ErrWikiReleaseAccessDenied)
		return
	}
	scope, err := newSchemaWikiScopeV1(head.WikiReleaseScope)
	if err != nil {
		writeSchemaWikiError(c, service.ErrWikiReleaseAccessDenied)
		return
	}
	c.JSON(http.StatusOK, gin.H{"success": true, "data": scope})
}

func (h *SchemaWikiHandler) PreparationScope(c *gin.Context) {
	_, _, scope, ok := schemaWikiPathScope(c)
	if !ok {
		writeSchemaWikiError(c, service.ErrWikiReleaseAccessDenied)
		return
	}
	response, err := newSchemaWikiScopeV1(scope)
	if err != nil {
		writeSchemaWikiError(c, err)
		return
	}
	c.JSON(http.StatusOK, gin.H{"success": true, "data": response})
}

func newSchemaWikiScopeV1(scope types.WikiReleaseScope) (schemaWikiScopeV1, error) {
	preimage := struct {
		Version  string `json:"version"`
		SpaceID  string `json:"space_id"`
		RawKBID  string `json:"raw_kb_id"`
		WikiKBID string `json:"wiki_kb_id"`
	}{
		Version: "schema-wiki-scope.v1", SpaceID: scope.SpaceID,
		RawKBID: scope.RawKBID, WikiKBID: scope.WikiKBID,
	}
	if strings.TrimSpace(preimage.SpaceID) == "" || strings.TrimSpace(preimage.RawKBID) == "" ||
		strings.TrimSpace(preimage.WikiKBID) == "" {
		return schemaWikiScopeV1{}, service.ErrWikiReleaseAccessDenied
	}
	canonical, err := json.Marshal(preimage)
	if err != nil {
		return schemaWikiScopeV1{}, service.ErrWikiReleaseAccessDenied
	}
	return schemaWikiScopeV1{
		Version: preimage.Version, SpaceID: preimage.SpaceID, RawKBID: preimage.RawKBID,
		WikiKBID: preimage.WikiKBID, ScopeSHA256: fmt.Sprintf("%x", sha256.Sum256(canonical)),
	}, nil
}

// Domains is the bounded active Schema Wiki read surface. The service pins the
// active Head and replays the complete stored Schema custody before returning
// any member; generic Wiki payloads never reach this response.
func (h *SchemaWikiHandler) Domains(c *gin.Context) {
	authority, err := h.currentAuthority(c)
	if err != nil {
		writeSchemaWikiError(c, err)
		return
	}
	c.JSON(http.StatusOK, gin.H{"success": true, "data": []types.KnowledgeDomainV1{authority.Domain}})
}

func (h *SchemaWikiHandler) CurrentTaxonomy(c *gin.Context) {
	authority, err := h.currentAuthority(c)
	if err != nil {
		writeSchemaWikiError(c, err)
		return
	}
	c.JSON(http.StatusOK, gin.H{"success": true, "data": authority.Taxonomy})
}

func (h *SchemaWikiHandler) CurrentEntityVersion(c *gin.Context) {
	authority, err := h.currentAuthority(c)
	if err == nil && (authority.Entity.EntityID != strings.TrimSpace(c.Param("entity_id")) ||
		authority.EntityVersion.VersionID != strings.TrimSpace(c.Param("version_id"))) {
		err = service.ErrWikiReleaseNotFound
	}
	if err == nil && (authority.ReleaseID == "" || authority.ActivationEpoch == 0 ||
		authority.Root.EntityID != authority.Entity.EntityID ||
		authority.Root.EntityVersionID != authority.EntityVersion.VersionID) {
		err = service.ErrWikiReleaseConflict
	}
	if err != nil {
		writeSchemaWikiError(c, err)
		return
	}
	c.JSON(http.StatusOK, gin.H{"success": true, "data": schemaWikiCurrentEntityVersionV1{
		Version:         "schema-wiki-current-entity-version.v1",
		EntityID:        authority.Entity.EntityID,
		EntityVersionID: authority.EntityVersion.VersionID,
		ActiveReleaseID: authority.ReleaseID,
		ActivationEpoch: authority.ActivationEpoch,
		Root:            authority.Root,
	}})
}

func (h *SchemaWikiHandler) ReadActiveRoot(c *gin.Context) {
	authority, err := h.currentAuthority(c)
	if err == nil && authority.ReleaseID != strings.TrimSpace(c.Param("release_id")) {
		err = service.ErrWikiReleaseConflict
	}
	if err != nil {
		writeSchemaWikiError(c, err)
		return
	}
	c.JSON(http.StatusOK, gin.H{"success": true, "data": authority.Root})
}

func (h *SchemaWikiHandler) currentAuthority(c *gin.Context) (*service.SchemaWikiCurrentAuthorityV1, error) {
	principal, scope, err := (&WikiReleaseHandler{}).requestIdentity(c)
	if err != nil {
		return nil, err
	}
	if h == nil || h.schemaService == nil {
		return nil, service.ErrNoSchemaWikiActiveRelease
	}
	authority, err := h.schemaService.ReadCurrentSchemaAuthority(c.Request.Context(), principal, scope)
	if err != nil {
		return nil, err
	}
	value, exists := c.Get(schemaWikiResolvedHeadContextKey)
	resolved, valid := value.(types.WikiReleaseHead)
	if !exists || !valid || authority == nil || resolved.WikiReleaseScope != scope ||
		resolved.ActiveReleaseID != authority.ReleaseID ||
		resolved.ActivationEpoch != authority.ActivationEpoch {
		return nil, service.ErrWikiReleaseConflict
	}
	return authority, nil
}

// CreateDraft accepts only the concrete release and review bundle. The
// service replays their closed custody and persists the immutable Draft.
func (h *SchemaWikiHandler) CreateDraft(c *gin.Context) {
	principal, scope, err := (&WikiReleaseHandler{}).requestIdentity(c)
	if err != nil {
		writeSchemaWikiError(c, err)
		return
	}
	if h == nil || h.schemaService == nil {
		writeSchemaWikiError(c, service.ErrSchemaWikiPreparationInvalid)
		return
	}
	var request schemaWikiCreateDraftRequest
	variant, err := decodeSchemaWikiCreateDraftRequest(c, &request)
	if err != nil {
		writeSchemaWikiError(c, err)
		return
	}
	var draft *types.WikiReleasePreparation
	if variant == "entity-page-graph-830-g1" {
		draft, err = h.schemaService.CreateEntityPageGraphDraft830G1(
			c.Request.Context(), principal, scope, strings.TrimSpace(request.PreparationID),
			request.EntityPageManifest,
		)
	} else if variant == "concept-free-wiki-830-g2" {
		creator, ok := h.schemaService.(interface {
			CreateConceptFreeWikiDraft830G2(
				context.Context, types.WikiReleasePrincipal, types.WikiReleaseScope,
				string, json.RawMessage,
			) (*types.WikiReleasePreparation, error)
		})
		if !ok {
			err = service.ErrSchemaWikiPreparationInvalid
		} else {
			draft, err = creator.CreateConceptFreeWikiDraft830G2(
				c.Request.Context(), principal, scope, strings.TrimSpace(request.PreparationID),
				request.ConceptCandidateBundle,
			)
		}
	} else if variant == "batch-concept-830-g3" {
		creator, ok := h.schemaService.(interface {
			CreateBatchConceptDraft830G3(
				context.Context, types.WikiReleasePrincipal, types.WikiReleaseScope,
				string, json.RawMessage,
			) (*types.WikiReleasePreparation, error)
		})
		if !ok {
			err = service.ErrSchemaWikiPreparationInvalid
		} else {
			draft, err = creator.CreateBatchConceptDraft830G3(
				c.Request.Context(), principal, scope, request.PreparationID,
				request.BatchConceptCandidateBundle,
			)
		}
	} else {
		draft, err = h.schemaService.CreateSchemaDraft(
			c.Request.Context(), principal, scope, strings.TrimSpace(request.PreparationID),
			request.Release, request.CandidateEvidenceAuthority, request.ReviewBundle,
			request.EvaluationBundle,
			request.ReviewSuccessor,
		)
	}
	if err != nil {
		writeSchemaWikiError(c, err)
		return
	}
	c.JSON(http.StatusCreated, gin.H{"success": true, "data": draft})
}

func decodeSchemaWikiCreateDraftRequest(
	c *gin.Context,
	destination *schemaWikiCreateDraftRequest,
) (string, error) {
	if c == nil || c.Request == nil || c.Request.Body == nil || destination == nil {
		return "", service.ErrSchemaWikiPreparationInvalid
	}
	raw, err := io.ReadAll(io.LimitReader(c.Request.Body, maxSchemaWikiRequestBytes+1))
	if err != nil || len(raw) == 0 || len(raw) > maxSchemaWikiRequestBytes {
		return "", service.ErrSchemaWikiPreparationInvalid
	}
	fields := map[string]json.RawMessage{}
	decoder := json.NewDecoder(bytes.NewReader(raw))
	opening, tokenErr := decoder.Token()
	if tokenErr != nil || opening != json.Delim('{') {
		return "", service.ErrSchemaWikiPreparationInvalid
	}
	for decoder.More() {
		token, tokenErr := decoder.Token()
		key, keyOK := token.(string)
		if tokenErr != nil || !keyOK {
			return "", service.ErrSchemaWikiPreparationInvalid
		}
		if _, duplicate := fields[key]; duplicate {
			return "", service.ErrSchemaWikiPreparationInvalid
		}
		var value json.RawMessage
		if decoder.Decode(&value) != nil {
			return "", service.ErrSchemaWikiPreparationInvalid
		}
		fields[key] = value
	}
	closing, tokenErr := decoder.Token()
	if tokenErr != nil || closing != json.Delim('}') || ensureWikiReleaseJSONEOF(decoder) != nil {
		return "", service.ErrSchemaWikiPreparationInvalid
	}
	hasExactKeys := func(expected ...string) bool {
		if len(fields) != len(expected) {
			return false
		}
		for _, key := range expected {
			if _, ok := fields[key]; !ok {
				return false
			}
		}
		return true
	}
	variant := ""
	switch {
	case hasExactKeys("preparation_id", "entity_page_manifest"):
		variant = "entity-page-graph-830-g1"
	case hasExactKeys("preparation_id", "concept_candidate_bundle"):
		variant = "concept-free-wiki-830-g2"
	case hasExactKeys("preparation_id", "batch_concept_candidate_bundle"):
		variant = "batch-concept-830-g3"
	case hasExactKeys(
		"preparation_id", "release", "candidate_evidence_authority", "review_bundle",
		"evaluation_bundle", "review_successor",
	):
		variant = "schema-wiki"
	default:
		return "", service.ErrSchemaWikiPreparationInvalid
	}
	decoder = json.NewDecoder(bytes.NewReader(raw))
	decoder.DisallowUnknownFields()
	if decoder.Decode(destination) != nil || ensureWikiReleaseJSONEOF(decoder) != nil ||
		strings.TrimSpace(destination.PreparationID) == "" ||
		(variant == "batch-concept-830-g3" &&
			bytes.Equal(bytes.TrimSpace(destination.BatchConceptCandidateBundle), []byte("null"))) {
		return "", service.ErrSchemaWikiPreparationInvalid
	}
	return variant, nil
}

// ReadBatchConceptPreparation830G3 returns one immutable Draft or Ready batch
// preparation after the shared human preparation guards seal both KB scopes.
func (h *SchemaWikiHandler) ReadBatchConceptPreparation830G3(c *gin.Context) {
	principal, scope, err := (&WikiReleaseHandler{}).requestIdentity(c)
	if err != nil {
		writeSchemaWikiError(c, err)
		return
	}
	if h == nil {
		writeSchemaWikiError(c, service.ErrSchemaWikiPreparationInvalid)
		return
	}
	reader, ok := h.schemaService.(interface {
		LoadBatchConceptPreparation830G3(
			context.Context, types.WikiReleasePrincipal, types.WikiReleaseScope, string,
		) (*service.BatchConceptPreparationRead830G3, error)
	})
	if !ok {
		writeSchemaWikiError(c, service.ErrSchemaWikiPreparationInvalid)
		return
	}
	response, err := reader.LoadBatchConceptPreparation830G3(
		c.Request.Context(), principal, scope, c.Param("preparation_id"),
	)
	if err != nil {
		writeSchemaWikiError(c, err)
		return
	}
	c.JSON(http.StatusOK, gin.H{"success": true, "data": response})
}

// ReviewDraft passes one closed named-human receipt to the existing concrete
// review authority; no caller-selected verifier or approval hash is accepted.
func (h *SchemaWikiHandler) ReviewDraft(c *gin.Context) {
	principal, scope, err := (&WikiReleaseHandler{}).requestIdentity(c)
	if err != nil {
		writeSchemaWikiError(c, err)
		return
	}
	if h == nil || h.schemaService == nil {
		writeSchemaWikiError(c, service.ErrSchemaWikiPreparationInvalid)
		return
	}
	var request schemaWikiReviewDraftRequest
	if err := decodeClosedSchemaWikiRequest(c, &request); err != nil || len(request.HumanDecision) == 0 {
		writeSchemaWikiError(c, service.ErrSchemaWikiPreparationInvalid)
		return
	}
	ready, err := h.schemaService.ReviewSchemaDraft(
		c.Request.Context(), principal, scope,
		strings.TrimSpace(c.Param("preparation_id")), request.HumanDecision,
	)
	if err != nil {
		writeSchemaWikiError(c, err)
		return
	}
	c.JSON(http.StatusOK, gin.H{"success": true, "data": ready})
}

// ReadDraftField is the human-only exact Draft preview. The caller supplies
// only the preparation, field and immutable member revision identities.
func (h *SchemaWikiHandler) ReadDraftField(c *gin.Context) {
	principal, scope, err := (&WikiReleaseHandler{}).requestIdentity(c)
	if err != nil {
		writeSchemaWikiError(c, err)
		return
	}
	if h == nil || h.schemaService == nil {
		writeSchemaWikiError(c, service.ErrSchemaWikiPreparationInvalid)
		return
	}
	member, err := h.schemaService.ReadSchemaDraftMember(
		c.Request.Context(), principal, scope,
		strings.TrimSpace(c.Param("preparation_id")),
		schemaWikiFieldSlug(c.Param("field_id")),
		strings.TrimSpace(c.Query("member_revision_id")),
	)
	if err != nil {
		writeSchemaWikiError(c, err)
		return
	}
	c.JSON(http.StatusOK, gin.H{"success": true, "data": member})
}

// ReadActiveField pins current Head inside the service and refuses release-id
// substitution before returning a canonical field payload.
func (h *SchemaWikiHandler) ReadActiveField(c *gin.Context) {
	h.readActiveMember(c, schemaWikiFieldSlug(c.Param("field_id")))
}

func (h *SchemaWikiHandler) ReadActiveSection(c *gin.Context) {
	h.readActiveMember(c, schemaWikiSectionSlug(c.Param("section_id")))
}

func (h *SchemaWikiHandler) readActiveMember(c *gin.Context, logicalSlug string) {
	principal, scope, err := (&WikiReleaseHandler{}).requestIdentity(c)
	if err != nil {
		writeSchemaWikiError(c, err)
		return
	}
	if h == nil || h.schemaService == nil {
		writeSchemaWikiError(c, service.ErrNoSchemaWikiActiveRelease)
		return
	}
	read, err := h.schemaService.ReadCurrentSchemaMember(
		c.Request.Context(), principal, scope, logicalSlug,
	)
	if err == nil && read.ReleaseID != strings.TrimSpace(c.Param("release_id")) {
		err = service.ErrWikiReleaseConflict
	}
	if err != nil {
		writeSchemaWikiError(c, err)
		return
	}
	c.JSON(http.StatusOK, gin.H{"success": true, "data": read.Payload})
}

// SearchActive pins and searches one Active release; the URL release must be
// identical to every server-derived result.
func (h *SchemaWikiHandler) SearchActive(c *gin.Context) {
	principal, scope, err := (&WikiReleaseHandler{}).requestIdentity(c)
	if err != nil {
		writeSchemaWikiError(c, err)
		return
	}
	if h == nil || h.schemaService == nil {
		writeSchemaWikiError(c, service.ErrNoSchemaWikiActiveRelease)
		return
	}
	reads, err := h.schemaService.SearchCurrentSchemaMembers(
		c.Request.Context(), principal, scope, c.Query("q"),
	)
	expectedReleaseID := strings.TrimSpace(c.Param("release_id"))
	if err == nil {
		for _, read := range reads {
			if read.ReleaseID != expectedReleaseID {
				err = service.ErrWikiReleaseConflict
				break
			}
		}
	}
	if err != nil {
		writeSchemaWikiError(c, err)
		return
	}
	c.JSON(http.StatusOK, gin.H{"success": true, "data": reads})
}

// ReadReviewedField returns only a full-custody Ready preparation field.
func (h *SchemaWikiHandler) ReadReviewedField(c *gin.Context) {
	h.readPreparationMember(c, schemaWikiFieldSlug(c.Param("field_id")))
}

func (h *SchemaWikiHandler) ReadReviewedSection(c *gin.Context) {
	h.readPreparationMember(c, schemaWikiSectionSlug(c.Param("section_id")))
}

func (h *SchemaWikiHandler) readPreparationMember(c *gin.Context, logicalSlug string) {
	principal, scope, err := (&WikiReleaseHandler{}).requestIdentity(c)
	if err != nil {
		writeSchemaWikiError(c, err)
		return
	}
	if h == nil || h.schemaService == nil {
		writeSchemaWikiError(c, service.ErrSchemaWikiPreparationInvalid)
		return
	}
	read, err := h.schemaService.ReadSchemaPreparationMember(
		c.Request.Context(), principal, scope,
		strings.TrimSpace(c.Param("preparation_id")), logicalSlug,
	)
	if err != nil {
		writeSchemaWikiError(c, err)
		return
	}
	c.JSON(http.StatusOK, gin.H{"success": true, "data": read.Payload})
}

func (h *SchemaWikiHandler) ReadReviewedRoot(c *gin.Context) {
	principal, scope, err := (&WikiReleaseHandler{}).requestIdentity(c)
	if err != nil {
		writeSchemaWikiError(c, err)
		return
	}
	if h == nil || h.schemaService == nil {
		writeSchemaWikiError(c, service.ErrSchemaWikiPreparationInvalid)
		return
	}
	read, err := h.schemaService.ReadSchemaPreparationMember(
		c.Request.Context(), principal, scope, strings.TrimSpace(c.Param("preparation_id")), "",
	)
	if err != nil {
		writeSchemaWikiError(c, err)
		return
	}
	c.JSON(http.StatusOK, gin.H{"success": true, "data": read.Payload})
}

func (h *SchemaWikiHandler) ReadPreparationGoldenQualitySummary(c *gin.Context) {
	principal, scope, err := (&WikiReleaseHandler{}).requestIdentity(c)
	if err != nil {
		writeSchemaWikiError(c, err)
		return
	}
	if h == nil || h.schemaService == nil {
		writeSchemaWikiError(c, service.ErrSchemaWikiPreparationInvalid)
		return
	}
	summary, err := h.schemaService.ReadSchemaPreparationGoldenQualitySummary(
		c.Request.Context(),
		principal,
		scope,
		strings.TrimSpace(c.Param("preparation_id")),
		strings.TrimSpace(c.Param("evaluation_id")),
	)
	if err != nil {
		writeSchemaWikiError(c, err)
		return
	}
	c.JSON(http.StatusOK, gin.H{"success": true, "data": summary})
}

func (h *SchemaWikiHandler) ReadPreparationGoldenQualityDossier(c *gin.Context) {
	principal, scope, err := (&WikiReleaseHandler{}).requestIdentity(c)
	if err != nil {
		writeSchemaWikiError(c, err)
		return
	}
	if h == nil || h.schemaService == nil {
		writeSchemaWikiError(c, service.ErrSchemaWikiPreparationInvalid)
		return
	}
	dossier, err := h.schemaService.ReadSchemaPreparationGoldenQualityDossier(
		c.Request.Context(),
		principal,
		scope,
		strings.TrimSpace(c.Param("preparation_id")),
		strings.TrimSpace(c.Param("evaluation_id")),
	)
	if err != nil {
		writeSchemaWikiError(c, err)
		return
	}
	c.JSON(http.StatusOK, gin.H{"success": true, "data": dossier})
}

// ReadGoldenSuccessorStatus exposes only the deployment-frozen, non-serving
// source-review/mapping/admission status. It accepts no caller payload.
func (h *SchemaWikiHandler) ReadGoldenSuccessorStatus(c *gin.Context) {
	principal, scope, err := (&WikiReleaseHandler{}).requestIdentity(c)
	if err != nil {
		writeSchemaWikiError(c, err)
		return
	}
	if h == nil || h.schemaService == nil {
		writeSchemaWikiError(c, service.ErrNoGoldenSuccessorStatus)
		return
	}
	status, err := h.schemaService.ReadSchemaWikiGoldenSuccessorStatus(
		c.Request.Context(), principal, scope,
	)
	if err != nil {
		writeSchemaWikiError(c, err)
		return
	}
	c.JSON(http.StatusOK, gin.H{"success": true, "data": status})
}

func (h *SchemaWikiHandler) PreviewPreparationGoldenEvidence(c *gin.Context) {
	principal, scope, err := (&WikiReleaseHandler{}).requestIdentity(c)
	if err != nil {
		writeSchemaWikiError(c, err)
		return
	}
	if h == nil || h.schemaService == nil {
		writeSchemaWikiError(c, service.ErrSchemaWikiCitationUnavailable)
		return
	}
	authority, err := h.schemaService.IssueSchemaPreparationGoldenEvidencePreview(
		c.Request.Context(),
		principal,
		scope,
		strings.TrimSpace(c.Param("preparation_id")),
		strings.TrimSpace(c.Param("evaluation_id")),
		strings.TrimSpace(c.Param("field_id")),
		strings.TrimSpace(c.Param("evidence_id")),
	)
	if err != nil {
		writeSchemaWikiError(c, err)
		return
	}
	c.JSON(http.StatusOK, gin.H{"success": true, "data": authority})
}

// PreviewCurrentCitation selects CitationTarget and binding from the pinned
// release inside the service. Only field/citation IDs cross the HTTP boundary.
func (h *SchemaWikiHandler) PreviewCurrentCitation(c *gin.Context) {
	principal, scope, err := (&WikiReleaseHandler{}).requestIdentity(c)
	if err != nil {
		writeSchemaWikiError(c, err)
		return
	}
	if h == nil || h.schemaService == nil {
		writeSchemaWikiError(c, service.ErrSchemaWikiCitationUnavailable)
		return
	}
	authority, err := h.schemaService.IssueCurrentSchemaCitationAuthority(
		c.Request.Context(), principal, scope,
		strings.TrimSpace(c.Param("release_id")),
		schemaWikiFieldSlug(c.Param("field_id")), strings.TrimSpace(c.Param("citation_id")),
	)
	if err != nil {
		writeSchemaWikiError(c, err)
		return
	}
	c.JSON(http.StatusOK, gin.H{"success": true, "data": authority})
}

func (h *SchemaWikiHandler) PreviewEntityPagePreparationCitation830G1(c *gin.Context) {
	principal, scope, err := (&WikiReleaseHandler{}).requestIdentity(c)
	if err != nil {
		writeSchemaWikiError(c, err)
		return
	}
	if h == nil || h.schemaService == nil {
		writeSchemaWikiError(c, service.ErrSchemaWikiCitationUnavailable)
		return
	}
	authority, err := h.schemaService.IssueEntityPageGraphPreparationCitationAuthority830G1(
		c.Request.Context(), principal, scope,
		strings.TrimSpace(c.Param("preparation_id")),
		strings.TrimSpace(c.Param("entity_id")),
		strings.TrimSpace(c.Param("field_key")),
		strings.TrimSpace(c.Param("citation_id")),
	)
	if err != nil {
		writeSchemaWikiError(c, err)
		return
	}
	c.JSON(http.StatusOK, gin.H{"success": true, "data": authority})
}

// ReadCitationContent accepts the opaque token as the sole citation/revision
// authority. The scoped URL remains only the independently sealed dual-ACL
// context and cannot select page, attempt, revision, bbox or hashes.
func (h *SchemaWikiHandler) ReadCitationContent(c *gin.Context) {
	principal, scope, err := (&WikiReleaseHandler{}).requestIdentity(c)
	if err != nil {
		writeSchemaWikiError(c, err)
		return
	}
	if h == nil || h.schemaService == nil {
		writeSchemaWikiError(c, service.ErrSchemaWikiCitationUnavailable)
		return
	}
	opened, err := h.schemaService.ReadSchemaCitationContent(
		c.Request.Context(), principal, scope, strings.TrimSpace(c.Param("token")),
	)
	if err != nil {
		writeSchemaWikiError(c, err)
		return
	}
	c.Data(http.StatusOK, "application/pdf", opened)
}

// PreviewReviewedCitation is the human-only Ready-preparation counterpart.
func (h *SchemaWikiHandler) PreviewReviewedCitation(c *gin.Context) {
	principal, scope, err := (&WikiReleaseHandler{}).requestIdentity(c)
	if err != nil {
		writeSchemaWikiError(c, err)
		return
	}
	if h == nil || h.schemaService == nil {
		writeSchemaWikiError(c, service.ErrSchemaWikiCitationUnavailable)
		return
	}
	opened, err := h.schemaService.ReadReviewedPreparationCitation(
		c.Request.Context(), principal, scope,
		strings.TrimSpace(c.Param("preparation_id")),
		schemaWikiFieldSlug(c.Param("field_id")), strings.TrimSpace(c.Param("citation_id")),
	)
	if err != nil {
		writeSchemaWikiError(c, err)
		return
	}
	c.Data(http.StatusOK, "application/octet-stream", opened)
}

func schemaWikiFieldSlug(fieldID string) string {
	fieldID = strings.TrimSpace(fieldID)
	if fieldID == "" {
		return ""
	}
	return "field:" + fieldID
}

func schemaWikiSectionSlug(sectionID string) string {
	sectionID = strings.TrimSpace(sectionID)
	if sectionID == "" {
		return ""
	}
	return "section:" + sectionID
}

func decodeClosedSchemaWikiRequest(c *gin.Context, destination any) error {
	if c == nil || c.Request == nil || c.Request.Body == nil {
		return service.ErrSchemaWikiPreparationInvalid
	}
	decoder := json.NewDecoder(io.LimitReader(c.Request.Body, maxSchemaWikiRequestBytes+1))
	decoder.DisallowUnknownFields()
	if err := decoder.Decode(destination); err != nil {
		return service.ErrSchemaWikiPreparationInvalid
	}
	if err := ensureWikiReleaseJSONEOF(decoder); err != nil {
		return service.ErrSchemaWikiPreparationInvalid
	}
	canonical, err := json.Marshal(destination)
	if err != nil || len(canonical) == 0 || bytes.Equal(bytes.TrimSpace(canonical), []byte("null")) {
		return service.ErrSchemaWikiPreparationInvalid
	}
	return nil
}

func writeSchemaWikiError(c *gin.Context, err error) {
	switch {
	case stderrors.Is(err, service.ErrSchemaWikiFormalCandidatePreviewRequestInvalid):
		c.JSON(http.StatusBadRequest, gin.H{"success": false, "error": gin.H{
			"code":    "SCHEMA_WIKI_FORMAL_CANDIDATE_PREVIEW_REQUEST_INVALID",
			"message": "schema wiki formal candidate preview request invalid",
		}})
	case stderrors.Is(err, service.ErrSchemaWikiFormalCandidatePreviewNotFound):
		c.JSON(http.StatusNotFound, gin.H{"success": false, "error": gin.H{
			"code":    "SCHEMA_WIKI_FORMAL_CANDIDATE_PREVIEW_NOT_FOUND",
			"message": "schema wiki formal candidate preview not found",
		}})
	case stderrors.Is(err, service.ErrSchemaWikiFormalCandidatePreviewBindingMismatch):
		c.JSON(http.StatusConflict, gin.H{"success": false, "error": gin.H{
			"code":    "SCHEMA_WIKI_FORMAL_CANDIDATE_PREVIEW_BINDING_MISMATCH",
			"message": "schema wiki formal candidate preview binding mismatch",
		}})
	case stderrors.Is(err, service.ErrSchemaWikiPreparationInvalid):
		c.JSON(http.StatusBadRequest, gin.H{
			"success": false, "error": gin.H{"message": "schema wiki preparation invalid"},
		})
	case stderrors.Is(err, service.ErrSchemaWikiCitationUnavailable):
		c.JSON(http.StatusServiceUnavailable, gin.H{
			"success": false, "error": gin.H{"message": "schema wiki citation unavailable"},
		})
	case stderrors.Is(err, service.ErrSchemaWikiCitationPageUnavailable):
		c.JSON(http.StatusUnprocessableEntity, gin.H{
			"success": false,
			"error": gin.H{
				"code": "PAGE_UNAVAILABLE", "message": "schema wiki citation page unavailable",
			},
		})
	case stderrors.Is(err, service.ErrNoSchemaWikiActiveRelease):
		c.JSON(http.StatusNotFound, gin.H{
			"success": false, "error": gin.H{"message": "no schema wiki active release"},
		})
	case stderrors.Is(err, service.ErrNoGoldenSuccessorStatus):
		c.JSON(http.StatusServiceUnavailable, gin.H{
			"success": false,
			"error": gin.H{
				"code": "NO_GOLDEN_SUCCESSOR_STATUS", "message": "golden successor status unavailable",
			},
		})
	default:
		writeWikiReleaseError(c, err)
	}
}
